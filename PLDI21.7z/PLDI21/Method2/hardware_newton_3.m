st=cputime;
cvx_begin
	variable a_init_i
	variable b_init
	variable a_loop_i
	variable b_loop
	variable a_l1_i
	variable b_l1
	variable a_l2_i
	variable b_l2
	variable a_l3_i
	variable b_l3
	variable a_l4_i
	variable b_l4
	variable a_lq_i
	variable b_lq
	minimize(0*a_init_i + b_init)
	subject to
		exp((41 * a_init_i) + b_init) >= 0 + 0.997003*exp((41 * a_loop_i) + b_loop)
		exp((0 * a_init_i) + b_init) >= 0 + 0.997003*exp((0 * a_loop_i) + b_loop)
		exp((40 * a_loop_i) + b_loop) >= 0 + 0.992523*exp((40 * a_l1_i) + b_l1)
		exp((0 * a_loop_i) + b_loop) >= 0 + 0.992523*exp((0 * a_l1_i) + b_l1)
		exp((41 * a_loop_i) + b_loop) >= 1
		exp((40 * a_l1_i) + b_l1) >= 1*exp((40 * a_l2_i) + b_l2)
		exp((0 * a_l1_i) + b_l1) >= 1*exp((0 * a_l2_i) + b_l2)
		exp((40 * a_l2_i) + b_l2) >= 0 + 0.999901*exp((40 * a_l3_i) + b_l3)
		exp((0 * a_l2_i) + b_l2) >= 0 + 0.999901*exp((0 * a_l3_i) + b_l3)
		exp((40 * a_l3_i) + b_l3) >= 0 + 0.999901*exp((40 * a_l4_i) + b_l4)
		exp((0 * a_l3_i) + b_l3) >= 0 + 0.999901*exp((0 * a_l4_i) + b_l4)
		exp((40 * a_l4_i) + b_l4) >= 0 + 0.997003*exp((40 * a_lq_i) + b_lq)
		exp((0 * a_l4_i) + b_l4) >= 0 + 0.997003*exp((0 * a_lq_i) + b_lq)
		exp((40 * a_lq_i) + b_lq) >= 0.991034*exp((41 * a_init_i) + b_init) + 0
		exp((0 * a_lq_i) + b_lq) >= 0.991034*exp((1 * a_init_i) + b_init) + 0
cvx_end
et=cputime-st


 %running time is  0.00249501  second!
