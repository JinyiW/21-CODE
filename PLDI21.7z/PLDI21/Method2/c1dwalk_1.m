st=cputime;
cvx_begin
	variable a_init_x
	variable a_init_y
	variable b_init
	variable a_assert_x
	variable a_assert_y
	variable b_assert
	minimize(0*a_init_x + 0*a_init_y + b_init)
	subject to
		(-1 * a_init_x) + (0 * a_init_y) >= (-1 * a_assert_x) + (0 * a_assert_y)
		(-1 * a_init_x) + (0 * a_init_y) >= (-1 * a_assert_x) + (0 * a_assert_y)
		exp((99 * a_init_x) + (500 * a_init_y) + b_init) >= 0.75*exp((100 * a_assert_x) + (501 * a_assert_y) + b_assert) + 0.25*exp((98 * a_assert_x) + (501 * a_assert_y) + b_assert)
		exp((99 * a_init_x) + (0 * a_init_y) + b_init) >= 0.75*exp((100 * a_assert_x) + (1 * a_assert_y) + b_assert) + 0.25*exp((98 * a_assert_x) + (1 * a_assert_y) + b_assert)
		exp((100 * a_init_x) + (0 * a_init_y) + b_init) >= 0
		exp((100 * a_init_x) + (500 * a_init_y) + b_init) >= 0
		(-1 * a_assert_x) + (0 * a_assert_y) >= (-1 * a_init_x) + (0 * a_init_y)
		exp((100 * a_assert_x) + (500 * a_assert_y) + b_assert) >= 1*exp((100 * a_init_x) + (500 * a_init_y) + b_init)
		exp((100 * a_assert_x) + (0 * a_assert_y) + b_assert) >= 1*exp((100 * a_init_x) + (0 * a_init_y) + b_init)
		(-1 * a_assert_x) + (0 * a_assert_y) >= 0
		exp((100 * a_assert_x) + (501 * a_assert_y) + b_assert) >= 1
cvx_end
et=cputime-st


 %running time is  0.00144301  second!
