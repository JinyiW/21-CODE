st=cputime;
cvx_begin
	variable a_init_x
	variable a_init_y
	variable b_init
	variable a_switch_x
	variable a_switch_y
	variable b_switch
	variable a_assert_x
	variable a_assert_y
	variable b_assert
	minimize(35*a_init_x + 0*a_init_y + b_init)
	subject to
		(0 * a_init_x) + (-1 * a_init_y) >= (0 * a_switch_x) + (-1 * a_switch_y)
		(-1 * a_init_x) + (0 * a_init_y) >= (-1 * a_switch_x) + (0 * a_switch_y)
		exp((99 * a_init_x) + (99 * a_init_y) + b_init) >= 1*exp((99 * a_switch_x) + (99 * a_switch_y) + b_switch)
		exp((99 * a_switch_x) + (99 * a_switch_y) + b_switch) >= 0.5*exp((100 * a_init_x) + (101 * a_init_y) + b_init) + 0.5*exp((100 * a_init_x) + (99 * a_init_y) + b_init)
		(0 * a_switch_x) + (-1 * a_switch_y) >= (0 * a_init_x) + (-1 * a_init_y)
		(0 * a_switch_x) + (-1 * a_switch_y) >= (0 * a_init_x) + (-1 * a_init_y)
		(-1 * a_switch_x) + (0 * a_switch_y) >= (-1 * a_init_x) + (0 * a_init_y)
		(-1 * a_switch_x) + (0 * a_switch_y) >= (-1 * a_init_x) + (0 * a_init_y)
		exp((100 * a_init_x) + (101 * a_init_y) + b_init) >= 1*exp((100 * a_assert_x) + (101 * a_assert_y) + b_assert)
		(0 * a_init_x) + (-1 * a_init_y) >= (0 * a_assert_x) + (-1 * a_assert_y)
		(-1 * a_init_x) + (0 * a_init_y) >= (-1 * a_assert_x) + (0 * a_assert_y)
		exp((100 * a_init_x) + (101 * a_init_y) + b_init) >= 1*exp((100 * a_assert_x) + (101 * a_assert_y) + b_assert)
		exp((100 * a_init_x) + (100 * a_init_y) + b_init) >= 1*exp((100 * a_assert_x) + (100 * a_assert_y) + b_assert)
		exp((100 * a_assert_x) + (0 * a_assert_y) + b_assert) >= 0
		exp((100 * a_assert_x) + (100 * a_assert_y) + b_assert) >= 0
		(0 * a_assert_x) + (1 * a_assert_y) >= 0
		exp((99 * a_assert_x) + (100 * a_assert_y) + b_assert) >= 1
		(-1 * a_assert_x) + (0 * a_assert_y) >= 0
cvx_end
et=cputime-st


 %running time is  0.00174701  second!
