st=cputime;
cvx_begin
	variable a_init_i
	variable a_init_j
	variable a_init_k
	variable b_init
	variable a_one_i
	variable a_one_j
	variable a_one_k
	variable b_one
	variable a_two_i
	variable a_two_j
	variable a_two_k
	variable b_two
	variable a_three_i
	variable a_three_j
	variable a_three_k
	variable b_three
	variable a_four_i
	variable a_four_j
	variable a_four_k
	variable b_four
	variable a_five_i
	variable a_five_j
	variable a_five_k
	variable b_five
	minimize(0*a_init_i + 0*a_init_j + 0*a_init_k + b_init)
	subject to
		exp((19 * a_init_i) + (0 * a_init_j) + (0 * a_init_k) + b_init) >= 1*exp((19 * a_one_i) + (0 * a_one_j) + (0 * a_one_k) + b_one)
		exp((19 * a_init_i) + (16 * a_init_j) + (0 * a_init_k) + b_init) >= 1*exp((19 * a_one_i) + (0 * a_one_j) + (0 * a_one_k) + b_one)
		exp((19 * a_init_i) + (16 * a_init_j) + (16 * a_init_k) + b_init) >= 1*exp((19 * a_one_i) + (0 * a_one_j) + (16 * a_one_k) + b_one)
		exp((19 * a_init_i) + (0 * a_init_j) + (16 * a_init_k) + b_init) >= 1*exp((19 * a_one_i) + (0 * a_one_j) + (16 * a_one_k) + b_one)
		exp((0 * a_init_i) + (0 * a_init_j) + (16 * a_init_k) + b_init) >= 1*exp((0 * a_one_i) + (0 * a_one_j) + (16 * a_one_k) + b_one)
		exp((0 * a_init_i) + (0 * a_init_j) + (0 * a_init_k) + b_init) >= 1*exp((0 * a_one_i) + (0 * a_one_j) + (0 * a_one_k) + b_one)
		exp((0 * a_init_i) + (16 * a_init_j) + (0 * a_init_k) + b_init) >= 1*exp((0 * a_one_i) + (0 * a_one_j) + (0 * a_one_k) + b_one)
		exp((0 * a_init_i) + (16 * a_init_j) + (16 * a_init_k) + b_init) >= 1*exp((0 * a_one_i) + (0 * a_one_j) + (16 * a_one_k) + b_one)
		exp((20 * a_init_i) + (0 * a_init_j) + (0 * a_init_k) + b_init) >= 1
		exp((20 * a_init_i) + (16 * a_init_j) + (0 * a_init_k) + b_init) >= 1
		exp((20 * a_init_i) + (16 * a_init_j) + (16 * a_init_k) + b_init) >= 1
		exp((20 * a_init_i) + (0 * a_init_j) + (16 * a_init_k) + b_init) >= 1
		exp((19 * a_one_i) + (16 * a_one_j) + (16 * a_one_k) + b_one) >= 1*exp((20 * a_init_i) + (16 * a_init_j) + (16 * a_init_k) + b_init)
		exp((19 * a_one_i) + (16 * a_one_j) + (0 * a_one_k) + b_one) >= 1*exp((20 * a_init_i) + (16 * a_init_j) + (0 * a_init_k) + b_init)
		exp((0 * a_one_i) + (16 * a_one_j) + (0 * a_one_k) + b_one) >= 1*exp((1 * a_init_i) + (16 * a_init_j) + (0 * a_init_k) + b_init)
		exp((0 * a_one_i) + (16 * a_one_j) + (16 * a_one_k) + b_one) >= 1*exp((1 * a_init_i) + (16 * a_init_j) + (16 * a_init_k) + b_init)
		exp((19 * a_one_i) + (0 * a_one_j) + (0 * a_one_k) + b_one) >= 1*exp((19 * a_two_i) + (0 * a_two_j) + (0 * a_two_k) + b_two)
		exp((19 * a_one_i) + (15 * a_one_j) + (0 * a_one_k) + b_one) >= 1*exp((19 * a_two_i) + (15 * a_two_j) + (0 * a_two_k) + b_two)
		exp((19 * a_one_i) + (15 * a_one_j) + (16 * a_one_k) + b_one) >= 1*exp((19 * a_two_i) + (15 * a_two_j) + (0 * a_two_k) + b_two)
		exp((19 * a_one_i) + (0 * a_one_j) + (16 * a_one_k) + b_one) >= 1*exp((19 * a_two_i) + (0 * a_two_j) + (0 * a_two_k) + b_two)
		exp((0 * a_one_i) + (0 * a_one_j) + (16 * a_one_k) + b_one) >= 1*exp((0 * a_two_i) + (0 * a_two_j) + (0 * a_two_k) + b_two)
		exp((0 * a_one_i) + (0 * a_one_j) + (0 * a_one_k) + b_one) >= 1*exp((0 * a_two_i) + (0 * a_two_j) + (0 * a_two_k) + b_two)
		exp((0 * a_one_i) + (15 * a_one_j) + (0 * a_one_k) + b_one) >= 1*exp((0 * a_two_i) + (15 * a_two_j) + (0 * a_two_k) + b_two)
		exp((0 * a_one_i) + (15 * a_one_j) + (16 * a_one_k) + b_one) >= 1*exp((0 * a_two_i) + (15 * a_two_j) + (0 * a_two_k) + b_two)
		exp((19 * a_two_i) + (0 * a_two_j) + (16 * a_two_k) + b_two) >= 1*exp((19 * a_one_i) + (1 * a_one_j) + (16 * a_one_k) + b_one)
		exp((19 * a_two_i) + (15 * a_two_j) + (16 * a_two_k) + b_two) >= 1*exp((19 * a_one_i) + (16 * a_one_j) + (16 * a_one_k) + b_one)
		exp((0 * a_two_i) + (15 * a_two_j) + (16 * a_two_k) + b_two) >= 1*exp((0 * a_one_i) + (16 * a_one_j) + (16 * a_one_k) + b_one)
		exp((0 * a_two_i) + (0 * a_two_j) + (16 * a_two_k) + b_two) >= 1*exp((0 * a_one_i) + (1 * a_one_j) + (16 * a_one_k) + b_one)
		exp((19 * a_two_i) + (0 * a_two_j) + (0 * a_two_k) + b_two) >= 0 + 1*exp((19 * a_three_i) + (0 * a_three_j) + (0 * a_three_k) + b_three)
		exp((19 * a_two_i) + (15 * a_two_j) + (0 * a_two_k) + b_two) >= 0 + 1*exp((19 * a_three_i) + (15 * a_three_j) + (0 * a_three_k) + b_three)
		exp((19 * a_two_i) + (15 * a_two_j) + (15 * a_two_k) + b_two) >= 0 + 1*exp((19 * a_three_i) + (15 * a_three_j) + (15 * a_three_k) + b_three)
		exp((19 * a_two_i) + (0 * a_two_j) + (15 * a_two_k) + b_two) >= 0 + 1*exp((19 * a_three_i) + (0 * a_three_j) + (15 * a_three_k) + b_three)
		exp((0 * a_two_i) + (0 * a_two_j) + (15 * a_two_k) + b_two) >= 0 + 1*exp((0 * a_three_i) + (0 * a_three_j) + (15 * a_three_k) + b_three)
		exp((0 * a_two_i) + (0 * a_two_j) + (0 * a_two_k) + b_two) >= 0 + 1*exp((0 * a_three_i) + (0 * a_three_j) + (0 * a_three_k) + b_three)
		exp((0 * a_two_i) + (15 * a_two_j) + (0 * a_two_k) + b_two) >= 0 + 1*exp((0 * a_three_i) + (15 * a_three_j) + (0 * a_three_k) + b_three)
		exp((0 * a_two_i) + (15 * a_two_j) + (15 * a_two_k) + b_two) >= 0 + 1*exp((0 * a_three_i) + (15 * a_three_j) + (15 * a_three_k) + b_three)
		exp((19 * a_three_i) + (0 * a_three_j) + (0 * a_three_k) + b_three) >= 1*exp((19 * a_four_i) + (0 * a_four_j) + (0 * a_four_k) + b_four) + 0
		exp((19 * a_three_i) + (15 * a_three_j) + (0 * a_three_k) + b_three) >= 1*exp((19 * a_four_i) + (15 * a_four_j) + (0 * a_four_k) + b_four) + 0
		exp((19 * a_three_i) + (15 * a_three_j) + (15 * a_three_k) + b_three) >= 1*exp((19 * a_four_i) + (15 * a_four_j) + (15 * a_four_k) + b_four) + 0
		exp((19 * a_three_i) + (0 * a_three_j) + (15 * a_three_k) + b_three) >= 1*exp((19 * a_four_i) + (0 * a_four_j) + (15 * a_four_k) + b_four) + 0
		exp((0 * a_three_i) + (0 * a_three_j) + (15 * a_three_k) + b_three) >= 1*exp((0 * a_four_i) + (0 * a_four_j) + (15 * a_four_k) + b_four) + 0
		exp((0 * a_three_i) + (0 * a_three_j) + (0 * a_three_k) + b_three) >= 1*exp((0 * a_four_i) + (0 * a_four_j) + (0 * a_four_k) + b_four) + 0
		exp((0 * a_three_i) + (15 * a_three_j) + (0 * a_three_k) + b_three) >= 1*exp((0 * a_four_i) + (15 * a_four_j) + (0 * a_four_k) + b_four) + 0
		exp((0 * a_three_i) + (15 * a_three_j) + (15 * a_three_k) + b_three) >= 1*exp((0 * a_four_i) + (15 * a_four_j) + (15 * a_four_k) + b_four) + 0
		exp((19 * a_four_i) + (0 * a_four_j) + (0 * a_four_k) + b_four) >= 0 + 1*exp((19 * a_five_i) + (0 * a_five_j) + (0 * a_five_k) + b_five)
		exp((19 * a_four_i) + (15 * a_four_j) + (0 * a_four_k) + b_four) >= 0 + 1*exp((19 * a_five_i) + (15 * a_five_j) + (0 * a_five_k) + b_five)
		exp((19 * a_four_i) + (15 * a_four_j) + (15 * a_four_k) + b_four) >= 0 + 1*exp((19 * a_five_i) + (15 * a_five_j) + (15 * a_five_k) + b_five)
		exp((19 * a_four_i) + (0 * a_four_j) + (15 * a_four_k) + b_four) >= 0 + 1*exp((19 * a_five_i) + (0 * a_five_j) + (15 * a_five_k) + b_five)
		exp((0 * a_four_i) + (0 * a_four_j) + (15 * a_four_k) + b_four) >= 0 + 1*exp((0 * a_five_i) + (0 * a_five_j) + (15 * a_five_k) + b_five)
		exp((0 * a_four_i) + (0 * a_four_j) + (0 * a_four_k) + b_four) >= 0 + 1*exp((0 * a_five_i) + (0 * a_five_j) + (0 * a_five_k) + b_five)
		exp((0 * a_four_i) + (15 * a_four_j) + (0 * a_four_k) + b_four) >= 0 + 1*exp((0 * a_five_i) + (15 * a_five_j) + (0 * a_five_k) + b_five)
		exp((0 * a_four_i) + (15 * a_four_j) + (15 * a_four_k) + b_four) >= 0 + 1*exp((0 * a_five_i) + (15 * a_five_j) + (15 * a_five_k) + b_five)
		exp((19 * a_five_i) + (0 * a_five_j) + (0 * a_five_k) + b_five) >= 0 + 1*exp((19 * a_two_i) + (0 * a_two_j) + (1 * a_two_k) + b_two)
		exp((19 * a_five_i) + (15 * a_five_j) + (0 * a_five_k) + b_five) >= 0 + 1*exp((19 * a_two_i) + (15 * a_two_j) + (1 * a_two_k) + b_two)
		exp((19 * a_five_i) + (15 * a_five_j) + (15 * a_five_k) + b_five) >= 0 + 1*exp((19 * a_two_i) + (15 * a_two_j) + (16 * a_two_k) + b_two)
		exp((19 * a_five_i) + (0 * a_five_j) + (15 * a_five_k) + b_five) >= 0 + 1*exp((19 * a_two_i) + (0 * a_two_j) + (16 * a_two_k) + b_two)
		exp((0 * a_five_i) + (0 * a_five_j) + (15 * a_five_k) + b_five) >= 0 + 1*exp((0 * a_two_i) + (0 * a_two_j) + (16 * a_two_k) + b_two)
		exp((0 * a_five_i) + (0 * a_five_j) + (0 * a_five_k) + b_five) >= 0 + 1*exp((0 * a_two_i) + (0 * a_two_j) + (1 * a_two_k) + b_two)
		exp((0 * a_five_i) + (15 * a_five_j) + (0 * a_five_k) + b_five) >= 0 + 1*exp((0 * a_two_i) + (15 * a_two_j) + (1 * a_two_k) + b_two)
		exp((0 * a_five_i) + (15 * a_five_j) + (15 * a_five_k) + b_five) >= 0 + 1*exp((0 * a_two_i) + (15 * a_two_j) + (16 * a_two_k) + b_two)
cvx_end
et=cputime-st


 %running time is  0.00319501  second!
