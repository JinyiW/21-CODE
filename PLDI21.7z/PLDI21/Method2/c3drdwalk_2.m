st=cputime;
cvx_begin
	variable a_init_x
	variable a_init_y
	variable a_init_z
	variable b_init
	variable a_la_x
	variable a_la_y
	variable a_la_z
	variable b_la
	variable a_b1_x
	variable a_b1_y
	variable a_b1_z
	variable b_b1
	variable a_b2_x
	variable a_b2_y
	variable a_b2_z
	variable b_b2
	minimize(100*a_init_x + 150*a_init_y + 200*a_init_z + b_init)
	subject to
		(0 * a_init_x) + (0 * a_init_y) + (1 * a_init_z) >= (0 * a_la_x) + (0 * a_la_y) + (1 * a_la_z)
		(0 * a_init_x) + (1 * a_init_y) + (0 * a_init_z) >= (0 * a_la_x) + (1 * a_la_y) + (0 * a_la_z)
		(1 * a_init_x) + (0 * a_init_y) + (0 * a_init_z) >= (1 * a_la_x) + (0 * a_la_y) + (0 * a_la_z)
		exp((0 * a_init_x) + (0 * a_init_y) + (0 * a_init_z) + b_init) >= 1*exp((0 * a_la_x) + (0 * a_la_y) + (0 * a_la_z) + b_la)
		exp((0 * a_init_x) + (-1 * a_init_y) + (-1 * a_init_z) + b_init) >= 0
		exp((-1 * a_init_x) + (-1 * a_init_y) + (-1 * a_init_z) + b_init) >= 0
		exp((-1 * a_init_x) + (0 * a_init_y) + (-1 * a_init_z) + b_init) >= 0
		exp((-1 * a_init_x) + (-1 * a_init_y) + (-1 * a_init_z) + b_init) >= 0
		exp((-1 * a_init_x) + (-1 * a_init_y) + (0 * a_init_z) + b_init) >= 0
		exp((-1 * a_init_x) + (-1 * a_init_y) + (-1 * a_init_z) + b_init) >= 0
		exp((1000 * a_la_x) + (0 * a_la_y) + (0 * a_la_z) + b_la) >= 0.900001*exp((1000 * a_b1_x) + (0 * a_b1_y) + (0 * a_b1_z) + b_b1) + 0.100001*exp((1000 * a_b2_x) + (0 * a_b2_y) + (0 * a_b2_z) + b_b2)
		exp((0 * a_la_x) + (1000 * a_la_y) + (0 * a_la_z) + b_la) >= 0.900001*exp((0 * a_b1_x) + (1000 * a_b1_y) + (0 * a_b1_z) + b_b1) + 0.100001*exp((0 * a_b2_x) + (1000 * a_b2_y) + (0 * a_b2_z) + b_b2)
		exp((0 * a_la_x) + (0 * a_la_y) + (0 * a_la_z) + b_la) >= 0.900001*exp((0 * a_b1_x) + (0 * a_b1_y) + (0 * a_b1_z) + b_b1) + 0.100001*exp((0 * a_b2_x) + (0 * a_b2_y) + (0 * a_b2_z) + b_b2)
		exp((0 * a_la_x) + (0 * a_la_y) + (1000 * a_la_z) + b_la) >= 0.900001*exp((0 * a_b1_x) + (0 * a_b1_y) + (1000 * a_b1_z) + b_b1) + 0.100001*exp((0 * a_b2_x) + (0 * a_b2_y) + (1000 * a_b2_z) + b_b2)
		exp((1000 * a_la_x) + (0 * a_la_y) + (0 * a_la_z) + b_la) >= 1
		exp((0 * a_la_x) + (1000 * a_la_y) + (0 * a_la_z) + b_la) >= 1
		exp((0 * a_la_x) + (0 * a_la_y) + (1000 * a_la_z) + b_la) >= 1
		exp((1000 * a_b1_x) + (0 * a_b1_y) + (0 * a_b1_z) + b_b1) >= 0.5*exp((999 * a_init_x) + (-1 * a_init_y) + (0 * a_init_z) + b_init) + 0.5*exp((1000 * a_init_x) + (0 * a_init_y) + (-1 * a_init_z) + b_init)
		exp((0 * a_b1_x) + (1000 * a_b1_y) + (0 * a_b1_z) + b_b1) >= 0.5*exp((-1 * a_init_x) + (999 * a_init_y) + (0 * a_init_z) + b_init) + 0.5*exp((0 * a_init_x) + (1000 * a_init_y) + (-1 * a_init_z) + b_init)
		exp((0 * a_b1_x) + (0 * a_b1_y) + (0 * a_b1_z) + b_b1) >= 0.5*exp((-1 * a_init_x) + (-1 * a_init_y) + (0 * a_init_z) + b_init) + 0.5*exp((0 * a_init_x) + (0 * a_init_y) + (-1 * a_init_z) + b_init)
		exp((0 * a_b1_x) + (0 * a_b1_y) + (1000 * a_b1_z) + b_b1) >= 0.5*exp((-1 * a_init_x) + (-1 * a_init_y) + (1000 * a_init_z) + b_init) + 0.5*exp((0 * a_init_x) + (0 * a_init_y) + (999 * a_init_z) + b_init)
		exp((1000 * a_b2_x) + (0 * a_b2_y) + (0 * a_b2_z) + b_b2) >= 0.5*exp((1000.11 * a_init_x) + (0.200001 * a_init_y) + (0 * a_init_z) + b_init) + 0.5*exp((1000 * a_init_x) + (0 * a_init_y) + (0.100001 * a_init_z) + b_init)
		exp((0 * a_b2_x) + (1000 * a_b2_y) + (0 * a_b2_z) + b_b2) >= 0.5*exp((0.100001 * a_init_x) + (1000.21 * a_init_y) + (0 * a_init_z) + b_init) + 0.5*exp((0 * a_init_x) + (1000 * a_init_y) + (0.100001 * a_init_z) + b_init)
		exp((0 * a_b2_x) + (0 * a_b2_y) + (0 * a_b2_z) + b_b2) >= 0.5*exp((0.100001 * a_init_x) + (0.200001 * a_init_y) + (0 * a_init_z) + b_init) + 0.5*exp((0 * a_init_x) + (0 * a_init_y) + (0.100001 * a_init_z) + b_init)
		exp((0 * a_b2_x) + (0 * a_b2_y) + (1000 * a_b2_z) + b_b2) >= 0.5*exp((0.100001 * a_init_x) + (0.200001 * a_init_y) + (1000 * a_init_z) + b_init) + 0.5*exp((0 * a_init_x) + (0 * a_init_y) + (1000.11 * a_init_z) + b_init)
cvx_end
et=cputime-st


 %running time is  0.00235201  second!
