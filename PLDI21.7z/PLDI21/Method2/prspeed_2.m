st=cputime;
cvx_begin
	variable a_init_x
	variable a_init_y
	variable a_init_t
	variable b_init
	variable a_b1_x
	variable a_b1_y
	variable a_b1_t
	variable b_b1
	variable a_la_x
	variable a_la_y
	variable a_la_t
	variable b_la
	minimize(10*a_init_x + 5*a_init_y + 0*a_init_t + b_init)
	subject to
		exp((17 * a_init_x) + (5 * a_init_y) + (0 * a_init_t) + b_init) >= 1*exp((17 * a_b1_x) + (5 * a_b1_y) + (0 * a_b1_t) + b_b1)
		exp((17 * a_init_x) + (5 * a_init_y) + (250 * a_init_t) + b_init) >= 1*exp((17 * a_b1_x) + (5 * a_b1_y) + (250 * a_b1_t) + b_b1)
		exp((17 * a_init_x) + (20 * a_init_y) + (15 * a_init_t) + b_init) >= 1*exp((17 * a_b1_x) + (20 * a_b1_y) + (15 * a_b1_t) + b_b1)
		exp((17 * a_init_x) + (20 * a_init_y) + (250 * a_init_t) + b_init) >= 1*exp((17 * a_b1_x) + (20 * a_b1_y) + (250 * a_b1_t) + b_b1)
		exp((10 * a_init_x) + (20 * a_init_y) + (250 * a_init_t) + b_init) >= 1*exp((10 * a_b1_x) + (20 * a_b1_y) + (250 * a_b1_t) + b_b1)
		exp((10 * a_init_x) + (5 * a_init_y) + (0 * a_init_t) + b_init) >= 1*exp((10 * a_b1_x) + (5 * a_b1_y) + (0 * a_b1_t) + b_b1)
		exp((10 * a_init_x) + (5 * a_init_y) + (250 * a_init_t) + b_init) >= 1*exp((10 * a_b1_x) + (5 * a_b1_y) + (250 * a_b1_t) + b_b1)
		exp((10 * a_init_x) + (20 * a_init_y) + (15 * a_init_t) + b_init) >= 1*exp((10 * a_b1_x) + (20 * a_b1_y) + (15 * a_b1_t) + b_b1)
		exp((20 * a_init_x) + (5 * a_init_y) + (250 * a_init_t) + b_init) >= 0
		exp((20 * a_init_x) + (5 * a_init_y) + (0 * a_init_t) + b_init) >= 0
		exp((20 * a_init_x) + (20 * a_init_y) + (15 * a_init_t) + b_init) >= 0
		exp((20 * a_init_x) + (20 * a_init_y) + (250 * a_init_t) + b_init) >= 0
		exp((18 * a_init_x) + (20 * a_init_y) + (250 * a_init_t) + b_init) >= 0
		exp((18 * a_init_x) + (5 * a_init_y) + (250 * a_init_t) + b_init) >= 0
		exp((18 * a_init_x) + (5 * a_init_y) + (0 * a_init_t) + b_init) >= 0
		exp((18 * a_init_x) + (20 * a_init_y) + (15 * a_init_t) + b_init) >= 0
		exp((17 * a_b1_x) + (5 * a_b1_y) + (250 * a_b1_t) + b_b1) >= 0.5*exp((17 * a_la_x) + (6 * a_la_y) + (251 * a_la_t) + b_la) + 0.5*exp((17 * a_la_x) + (5 * a_la_y) + (251 * a_la_t) + b_la)
		exp((17 * a_b1_x) + (5 * a_b1_y) + (0 * a_b1_t) + b_b1) >= 0.5*exp((17 * a_la_x) + (6 * a_la_y) + (1 * a_la_t) + b_la) + 0.5*exp((17 * a_la_x) + (5 * a_la_y) + (1 * a_la_t) + b_la)
		exp((17 * a_b1_x) + (19 * a_b1_y) + (250 * a_b1_t) + b_b1) >= 0.5*exp((17 * a_la_x) + (20 * a_la_y) + (251 * a_la_t) + b_la) + 0.5*exp((17 * a_la_x) + (19 * a_la_y) + (251 * a_la_t) + b_la)
		exp((17 * a_b1_x) + (19 * a_b1_y) + (14 * a_b1_t) + b_b1) >= 0.5*exp((17 * a_la_x) + (20 * a_la_y) + (15 * a_la_t) + b_la) + 0.5*exp((17 * a_la_x) + (19 * a_la_y) + (15 * a_la_t) + b_la)
		exp((10 * a_b1_x) + (19 * a_b1_y) + (14 * a_b1_t) + b_b1) >= 0.5*exp((10 * a_la_x) + (20 * a_la_y) + (15 * a_la_t) + b_la) + 0.5*exp((10 * a_la_x) + (19 * a_la_y) + (15 * a_la_t) + b_la)
		exp((10 * a_b1_x) + (5 * a_b1_y) + (250 * a_b1_t) + b_b1) >= 0.5*exp((10 * a_la_x) + (6 * a_la_y) + (251 * a_la_t) + b_la) + 0.5*exp((10 * a_la_x) + (5 * a_la_y) + (251 * a_la_t) + b_la)
		exp((10 * a_b1_x) + (5 * a_b1_y) + (0 * a_b1_t) + b_b1) >= 0.5*exp((10 * a_la_x) + (6 * a_la_y) + (1 * a_la_t) + b_la) + 0.5*exp((10 * a_la_x) + (5 * a_la_y) + (1 * a_la_t) + b_la)
		exp((10 * a_b1_x) + (19 * a_b1_y) + (250 * a_b1_t) + b_b1) >= 0.5*exp((10 * a_la_x) + (20 * a_la_y) + (251 * a_la_t) + b_la) + 0.5*exp((10 * a_la_x) + (19 * a_la_y) + (251 * a_la_t) + b_la)
		exp((17 * a_b1_x) + (20 * a_b1_y) + (15 * a_b1_t) + b_b1) >= 0.25*exp((17 * a_la_x) + (20 * a_la_y) + (16 * a_la_t) + b_la) + 0.25*exp((18 * a_la_x) + (20 * a_la_y) + (16 * a_la_t) + b_la) + 0.25*exp((19 * a_la_x) + (20 * a_la_y) + (16 * a_la_t) + b_la) + 0.25*exp((20 * a_la_x) + (20 * a_la_y) + (16 * a_la_t) + b_la)
		exp((17 * a_b1_x) + (20 * a_b1_y) + (250 * a_b1_t) + b_b1) >= 0.25*exp((17 * a_la_x) + (20 * a_la_y) + (251 * a_la_t) + b_la) + 0.25*exp((18 * a_la_x) + (20 * a_la_y) + (251 * a_la_t) + b_la) + 0.25*exp((19 * a_la_x) + (20 * a_la_y) + (251 * a_la_t) + b_la) + 0.25*exp((20 * a_la_x) + (20 * a_la_y) + (251 * a_la_t) + b_la)
		exp((10 * a_b1_x) + (20 * a_b1_y) + (250 * a_b1_t) + b_b1) >= 0.25*exp((10 * a_la_x) + (20 * a_la_y) + (251 * a_la_t) + b_la) + 0.25*exp((11 * a_la_x) + (20 * a_la_y) + (251 * a_la_t) + b_la) + 0.25*exp((12 * a_la_x) + (20 * a_la_y) + (251 * a_la_t) + b_la) + 0.25*exp((13 * a_la_x) + (20 * a_la_y) + (251 * a_la_t) + b_la)
		exp((10 * a_b1_x) + (20 * a_b1_y) + (15 * a_b1_t) + b_b1) >= 0.25*exp((10 * a_la_x) + (20 * a_la_y) + (16 * a_la_t) + b_la) + 0.25*exp((11 * a_la_x) + (20 * a_la_y) + (16 * a_la_t) + b_la) + 0.25*exp((12 * a_la_x) + (20 * a_la_y) + (16 * a_la_t) + b_la) + 0.25*exp((13 * a_la_x) + (20 * a_la_y) + (16 * a_la_t) + b_la)
		exp((20 * a_la_x) + (5 * a_la_y) + (250 * a_la_t) + b_la) >= 1*exp((20 * a_init_x) + (5 * a_init_y) + (250 * a_init_t) + b_init)
		exp((20 * a_la_x) + (5 * a_la_y) + (0 * a_la_t) + b_la) >= 1*exp((20 * a_init_x) + (5 * a_init_y) + (0 * a_init_t) + b_init)
		exp((20 * a_la_x) + (20 * a_la_y) + (15 * a_la_t) + b_la) >= 1*exp((20 * a_init_x) + (20 * a_init_y) + (15 * a_init_t) + b_init)
		exp((20 * a_la_x) + (20 * a_la_y) + (250 * a_la_t) + b_la) >= 1*exp((20 * a_init_x) + (20 * a_init_y) + (250 * a_init_t) + b_init)
		exp((10 * a_la_x) + (20 * a_la_y) + (250 * a_la_t) + b_la) >= 1*exp((10 * a_init_x) + (20 * a_init_y) + (250 * a_init_t) + b_init)
		exp((10 * a_la_x) + (5 * a_la_y) + (250 * a_la_t) + b_la) >= 1*exp((10 * a_init_x) + (5 * a_init_y) + (250 * a_init_t) + b_init)
		exp((10 * a_la_x) + (5 * a_la_y) + (0 * a_la_t) + b_la) >= 1*exp((10 * a_init_x) + (5 * a_init_y) + (0 * a_init_t) + b_init)
		exp((10 * a_la_x) + (20 * a_la_y) + (15 * a_la_t) + b_la) >= 1*exp((10 * a_init_x) + (20 * a_init_y) + (15 * a_init_t) + b_init)
		exp((20 * a_la_x) + (5 * a_la_y) + (251 * a_la_t) + b_la) >= 1
		exp((20 * a_la_x) + (20 * a_la_y) + (251 * a_la_t) + b_la) >= 1
		exp((10 * a_la_x) + (20 * a_la_y) + (251 * a_la_t) + b_la) >= 1
		exp((10 * a_la_x) + (5 * a_la_y) + (251 * a_la_t) + b_la) >= 1
cvx_end
et=cputime-st


 %running time is  0.00235801  second!
