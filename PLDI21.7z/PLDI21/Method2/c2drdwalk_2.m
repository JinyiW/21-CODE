st=cputime;
cvx_begin
	variable a_init_x
	variable a_init_y
	variable b_init
	variable a_cx_x
	variable a_cx_y
	variable b_cx
	variable a_cy_x
	variable a_cy_y
	variable b_cy
	variable a_la_x
	variable a_la_y
	variable b_la
	minimize(500*a_init_x + 40*a_init_y + b_init)
	subject to
		(1 * a_init_x) + (0 * a_init_y) >= (1 * a_cx_x) + (0 * a_cx_y)
		(1 * a_init_x) + (0 * a_init_y) >= (1 * a_cy_x) + (0 * a_cy_y)
		(0 * a_init_x) + (1 * a_init_y) >= (0 * a_cx_x) + (1 * a_cx_y)
		(0 * a_init_x) + (1 * a_init_y) >= (0 * a_cy_x) + (1 * a_cy_y)
		exp((1 * a_init_x) + (1 * a_init_y) + b_init) >= 0.5*exp((1 * a_cx_x) + (1 * a_cx_y) + b_cx) + 0.5*exp((1 * a_cy_x) + (1 * a_cy_y) + b_cy)
		exp((1 * a_init_x) + (0 * a_init_y) + b_init) >= 0
		(1 * a_cx_x) + (0 * a_cx_y) >= (1 * a_la_x) + (0 * a_la_y)
		(1 * a_cx_x) + (0 * a_cx_y) >= (1 * a_la_x) + (0 * a_la_y)
		(0 * a_cx_x) + (1 * a_cx_y) >= (0 * a_la_x) + (1 * a_la_y)
		(0 * a_cx_x) + (1 * a_cx_y) >= (0 * a_la_x) + (1 * a_la_y)
		exp((1 * a_cx_x) + (1 * a_cx_y) + b_cx) >= 0.75*exp((2 * a_la_x) + (1 * a_la_y) + b_la) + 0.25*exp((0 * a_la_x) + (1 * a_la_y) + b_la)
		(1 * a_cy_x) + (0 * a_cy_y) >= (1 * a_la_x) + (0 * a_la_y)
		(1 * a_cy_x) + (0 * a_cy_y) >= (1 * a_la_x) + (0 * a_la_y)
		(0 * a_cy_x) + (1 * a_cy_y) >= (0 * a_la_x) + (1 * a_la_y)
		(0 * a_cy_x) + (1 * a_cy_y) >= (0 * a_la_x) + (1 * a_la_y)
		exp((1 * a_cy_x) + (1 * a_cy_y) + b_cy) >= 0.75*exp((1 * a_la_x) + (0 * a_la_y) + b_la) + 0.25*exp((1 * a_la_x) + (2 * a_la_y) + b_la)
		(0 * a_la_x) + (1 * a_la_y) >= (0 * a_init_x) + (1 * a_init_y)
		(1 * a_la_x) + (0 * a_la_y) >= (1 * a_init_x) + (0 * a_init_y)
		exp((1 * a_la_x) + (0 * a_la_y) + b_la) >= 1*exp((1 * a_init_x) + (0 * a_init_y) + b_init)
		(0 * a_la_x) + (1 * a_la_y) >= 0
		exp((0 * a_la_x) + (0 * a_la_y) + b_la) >= 1
cvx_end
et=cputime-st


 %running time is  0.00204701  second!
