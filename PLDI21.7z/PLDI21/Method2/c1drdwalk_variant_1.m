st=cputime;
cvx_begin
	variable a_init_x
	variable b_init
	variable a_la_x
	variable b_la
	variable a_b1_x
	variable b_b1
	minimize(10*a_init_x + b_init)
	subject to
		exp((1001 * a_init_x) + b_init) >= 1*exp((1001 * a_la_x) + b_la)
		exp((0 * a_init_x) + b_init) >= 1*exp((0 * a_la_x) + b_la)
		exp((-1 * a_init_x) + b_init) >= 0
		exp((-2 * a_init_x) + b_init) >= 0
		exp((1000 * a_la_x) + b_la) >= 1*exp((1000 * a_b1_x) + b_b1)
		exp((0 * a_la_x) + b_la) >= 1*exp((0 * a_b1_x) + b_b1)
		exp((1001 * a_la_x) + b_la) >= 1
		exp((1000 * a_b1_x) + b_b1) >= 0.5*exp((998 * a_init_x) + b_init) + 0.5*exp((1001 * a_init_x) + b_init)
		exp((0 * a_b1_x) + b_b1) >= 0.5*exp((-2 * a_init_x) + b_init) + 0.5*exp((1 * a_init_x) + b_init)
cvx_end
et=cputime-st


 %running time is  0.00173101  second!
