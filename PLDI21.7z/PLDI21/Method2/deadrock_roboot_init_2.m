st=cputime;
cvx_begin
	variable a_init_i
	variable a_init_x
	variable a_init_ex
	variable a_init_dxc
	variable b_init
	variable a_lp_i
	variable a_lp_x
	variable a_lp_ex
	variable a_lp_dxc
	variable b_lp
	variable a_la_i
	variable a_la_x
	variable a_la_ex
	variable a_la_dxc
	variable b_la
	minimize(0*a_init_i + 0*a_init_x + 0*a_init_ex + 0*a_init_dxc + b_init)
	subject to
		(0 * a_init_i) + (0 * a_init_x) + (0 * a_init_ex) + (1 * a_init_dxc) >= (0 * a_lp_i) + (0 * a_lp_x) + (0 * a_lp_ex) + (0 * a_lp_dxc)
		(0 * a_init_i) + (0 * a_init_x) + (0 * a_init_ex) + (1 * a_init_dxc) >= (0 * a_lp_i) + (0 * a_lp_x) + (0 * a_lp_ex) + (0 * a_lp_dxc)
		(0 * a_init_i) + (0 * a_init_x) + (0 * a_init_ex) + (1 * a_init_dxc) >= (0 * a_lp_i) + (0 * a_lp_x) + (0 * a_lp_ex) + (0 * a_lp_dxc)
		(0 * a_init_i) + (0 * a_init_x) + (0 * a_init_ex) + (1 * a_init_dxc) >= (0 * a_lp_i) + (0 * a_lp_x) + (0 * a_lp_ex) + (0 * a_lp_dxc)
		(0 * a_init_i) + (0 * a_init_x) + (0 * a_init_ex) + (1 * a_init_dxc) >= (0 * a_lp_i) + (0 * a_lp_x) + (0 * a_lp_ex) + (0 * a_lp_dxc)
		(0 * a_init_i) + (0 * a_init_x) + (0 * a_init_ex) + (1 * a_init_dxc) >= (0 * a_lp_i) + (0 * a_lp_x) + (0 * a_lp_ex) + (0 * a_lp_dxc)
		(0 * a_init_i) + (0 * a_init_x) + (0 * a_init_ex) + (1 * a_init_dxc) >= (0 * a_lp_i) + (0 * a_lp_x) + (0 * a_lp_ex) + (0 * a_lp_dxc)
		(0 * a_init_i) + (0 * a_init_x) + (0 * a_init_ex) + (1 * a_init_dxc) >= (0 * a_lp_i) + (0 * a_lp_x) + (0 * a_lp_ex) + (0 * a_lp_dxc)
		(0 * a_init_i) + (0 * a_init_x) + (0 * a_init_ex) + (1 * a_init_dxc) >= (0 * a_lp_i) + (0 * a_lp_x) + (0 * a_lp_ex) + (0 * a_lp_dxc)
		(-0 * a_init_i) + (-0 * a_init_x) + (-0 * a_init_ex) + (-1 * a_init_dxc) >= (0 * a_lp_i) + (0 * a_lp_x) + (0 * a_lp_ex) + (0 * a_lp_dxc)
		(-0 * a_init_i) + (-0 * a_init_x) + (-0 * a_init_ex) + (-1 * a_init_dxc) >= (0 * a_lp_i) + (0 * a_lp_x) + (0 * a_lp_ex) + (0 * a_lp_dxc)
		(-0 * a_init_i) + (-0 * a_init_x) + (-0 * a_init_ex) + (-1 * a_init_dxc) >= (0 * a_lp_i) + (0 * a_lp_x) + (0 * a_lp_ex) + (0 * a_lp_dxc)
		(-0 * a_init_i) + (-0 * a_init_x) + (-0 * a_init_ex) + (-1 * a_init_dxc) >= (0 * a_lp_i) + (0 * a_lp_x) + (0 * a_lp_ex) + (0 * a_lp_dxc)
		(-0 * a_init_i) + (-0 * a_init_x) + (-0 * a_init_ex) + (-1 * a_init_dxc) >= (0 * a_lp_i) + (0 * a_lp_x) + (0 * a_lp_ex) + (0 * a_lp_dxc)
		(-0 * a_init_i) + (-0 * a_init_x) + (-0 * a_init_ex) + (-1 * a_init_dxc) >= (0 * a_lp_i) + (0 * a_lp_x) + (0 * a_lp_ex) + (0 * a_lp_dxc)
		(-0 * a_init_i) + (-0 * a_init_x) + (-0 * a_init_ex) + (-1 * a_init_dxc) >= (0 * a_lp_i) + (0 * a_lp_x) + (0 * a_lp_ex) + (0 * a_lp_dxc)
		(-0 * a_init_i) + (-0 * a_init_x) + (-0 * a_init_ex) + (-1 * a_init_dxc) >= (0 * a_lp_i) + (0 * a_lp_x) + (0 * a_lp_ex) + (0 * a_lp_dxc)
		(-0 * a_init_i) + (-0 * a_init_x) + (-0 * a_init_ex) + (-1 * a_init_dxc) >= (0 * a_lp_i) + (0 * a_lp_x) + (0 * a_lp_ex) + (0 * a_lp_dxc)
		exp((0 * a_init_i) + (0 * a_init_x) + (0 * a_init_ex) + (0 * a_init_dxc) + b_init) >= 0.100001*exp((0 * a_lp_i) + (0 * a_lp_x) + (0 * a_lp_ex) + (-5 * a_lp_dxc) + b_lp) + 0.100001*exp((0 * a_lp_i) + (0 * a_lp_x) + (0 * a_lp_ex) + (-5 * a_lp_dxc) + b_lp) + 0.100001*exp((0 * a_lp_i) + (0 * a_lp_x) + (0 * a_lp_ex) + (5 * a_lp_dxc) + b_lp) + 0.100001*exp((0 * a_lp_i) + (0 * a_lp_x) + (0 * a_lp_ex) + (5 * a_lp_dxc) + b_lp) + 0.100001*exp((0 * a_lp_i) + (0 * a_lp_x) + (0 * a_lp_ex) + (0 * a_lp_dxc) + b_lp) + 0.100001*exp((0 * a_lp_i) + (0 * a_lp_x) + (0 * a_lp_ex) + (0 * a_lp_dxc) + b_lp) + 0.100001*exp((0 * a_lp_i) + (0 * a_lp_x) + (0 * a_lp_ex) + (0.500001 * a_lp_dxc) + b_lp) + 0.100001*exp((0 * a_lp_i) + (0 * a_lp_x) + (0 * a_lp_ex) + (-0.5 * a_lp_dxc) + b_lp) + 0.200001*exp((0 * a_lp_i) + (0 * a_lp_x) + (0 * a_lp_ex) + (0 * a_lp_dxc) + b_lp)
		exp((59 * a_init_i) + (292.051 * a_init_x) + (295 * a_init_ex) + (0 * a_init_dxc) + b_init) >= 0.100001*exp((59 * a_lp_i) + (292.051 * a_lp_x) + (295 * a_lp_ex) + (-5 * a_lp_dxc) + b_lp) + 0.100001*exp((59 * a_lp_i) + (292.051 * a_lp_x) + (295 * a_lp_ex) + (-5 * a_lp_dxc) + b_lp) + 0.100001*exp((59 * a_lp_i) + (292.051 * a_lp_x) + (295 * a_lp_ex) + (5 * a_lp_dxc) + b_lp) + 0.100001*exp((59 * a_lp_i) + (292.051 * a_lp_x) + (295 * a_lp_ex) + (5 * a_lp_dxc) + b_lp) + 0.100001*exp((59 * a_lp_i) + (292.051 * a_lp_x) + (295 * a_lp_ex) + (0 * a_lp_dxc) + b_lp) + 0.100001*exp((59 * a_lp_i) + (292.051 * a_lp_x) + (295 * a_lp_ex) + (0 * a_lp_dxc) + b_lp) + 0.100001*exp((59 * a_lp_i) + (292.051 * a_lp_x) + (295 * a_lp_ex) + (0.500001 * a_lp_dxc) + b_lp) + 0.100001*exp((59 * a_lp_i) + (292.051 * a_lp_x) + (295 * a_lp_ex) + (-0.5 * a_lp_dxc) + b_lp) + 0.200001*exp((59 * a_lp_i) + (292.051 * a_lp_x) + (295 * a_lp_ex) + (0 * a_lp_dxc) + b_lp)
		exp((59 * a_init_i) + (297.951 * a_init_x) + (295 * a_init_ex) + (0 * a_init_dxc) + b_init) >= 0.100001*exp((59 * a_lp_i) + (297.951 * a_lp_x) + (295 * a_lp_ex) + (-5 * a_lp_dxc) + b_lp) + 0.100001*exp((59 * a_lp_i) + (297.951 * a_lp_x) + (295 * a_lp_ex) + (-5 * a_lp_dxc) + b_lp) + 0.100001*exp((59 * a_lp_i) + (297.951 * a_lp_x) + (295 * a_lp_ex) + (5 * a_lp_dxc) + b_lp) + 0.100001*exp((59 * a_lp_i) + (297.951 * a_lp_x) + (295 * a_lp_ex) + (5 * a_lp_dxc) + b_lp) + 0.100001*exp((59 * a_lp_i) + (297.951 * a_lp_x) + (295 * a_lp_ex) + (0 * a_lp_dxc) + b_lp) + 0.100001*exp((59 * a_lp_i) + (297.951 * a_lp_x) + (295 * a_lp_ex) + (0 * a_lp_dxc) + b_lp) + 0.100001*exp((59 * a_lp_i) + (297.951 * a_lp_x) + (295 * a_lp_ex) + (0.500001 * a_lp_dxc) + b_lp) + 0.100001*exp((59 * a_lp_i) + (297.951 * a_lp_x) + (295 * a_lp_ex) + (-0.5 * a_lp_dxc) + b_lp) + 0.200001*exp((59 * a_lp_i) + (297.951 * a_lp_x) + (295 * a_lp_ex) + (0 * a_lp_dxc) + b_lp)
		exp((59 * a_init_i) + (-292.049 * a_init_x) + (-295 * a_init_ex) + (0 * a_init_dxc) + b_init) >= 0.100001*exp((59 * a_lp_i) + (-292.049 * a_lp_x) + (-295 * a_lp_ex) + (-5 * a_lp_dxc) + b_lp) + 0.100001*exp((59 * a_lp_i) + (-292.049 * a_lp_x) + (-295 * a_lp_ex) + (-5 * a_lp_dxc) + b_lp) + 0.100001*exp((59 * a_lp_i) + (-292.049 * a_lp_x) + (-295 * a_lp_ex) + (5 * a_lp_dxc) + b_lp) + 0.100001*exp((59 * a_lp_i) + (-292.049 * a_lp_x) + (-295 * a_lp_ex) + (5 * a_lp_dxc) + b_lp) + 0.100001*exp((59 * a_lp_i) + (-292.049 * a_lp_x) + (-295 * a_lp_ex) + (0 * a_lp_dxc) + b_lp) + 0.100001*exp((59 * a_lp_i) + (-292.049 * a_lp_x) + (-295 * a_lp_ex) + (0 * a_lp_dxc) + b_lp) + 0.100001*exp((59 * a_lp_i) + (-292.049 * a_lp_x) + (-295 * a_lp_ex) + (0.500001 * a_lp_dxc) + b_lp) + 0.100001*exp((59 * a_lp_i) + (-292.049 * a_lp_x) + (-295 * a_lp_ex) + (-0.5 * a_lp_dxc) + b_lp) + 0.200001*exp((59 * a_lp_i) + (-292.049 * a_lp_x) + (-295 * a_lp_ex) + (0 * a_lp_dxc) + b_lp)
		exp((59 * a_init_i) + (-297.949 * a_init_x) + (-295 * a_init_ex) + (0 * a_init_dxc) + b_init) >= 0.100001*exp((59 * a_lp_i) + (-297.949 * a_lp_x) + (-295 * a_lp_ex) + (-5 * a_lp_dxc) + b_lp) + 0.100001*exp((59 * a_lp_i) + (-297.949 * a_lp_x) + (-295 * a_lp_ex) + (-5 * a_lp_dxc) + b_lp) + 0.100001*exp((59 * a_lp_i) + (-297.949 * a_lp_x) + (-295 * a_lp_ex) + (5 * a_lp_dxc) + b_lp) + 0.100001*exp((59 * a_lp_i) + (-297.949 * a_lp_x) + (-295 * a_lp_ex) + (5 * a_lp_dxc) + b_lp) + 0.100001*exp((59 * a_lp_i) + (-297.949 * a_lp_x) + (-295 * a_lp_ex) + (0 * a_lp_dxc) + b_lp) + 0.100001*exp((59 * a_lp_i) + (-297.949 * a_lp_x) + (-295 * a_lp_ex) + (0 * a_lp_dxc) + b_lp) + 0.100001*exp((59 * a_lp_i) + (-297.949 * a_lp_x) + (-295 * a_lp_ex) + (0.500001 * a_lp_dxc) + b_lp) + 0.100001*exp((59 * a_lp_i) + (-297.949 * a_lp_x) + (-295 * a_lp_ex) + (-0.5 * a_lp_dxc) + b_lp) + 0.200001*exp((59 * a_lp_i) + (-297.949 * a_lp_x) + (-295 * a_lp_ex) + (0 * a_lp_dxc) + b_lp)
		(0 * a_lp_i) + (0 * a_lp_x) + (0 * a_lp_ex) + (1 * a_lp_dxc) >= (0 * a_init_i) + (1 * a_init_x) + (1 * a_init_ex) + (1 * a_init_dxc)
		(0 * a_lp_i) + (0 * a_lp_x) + (0 * a_lp_ex) + (1 * a_lp_dxc) >= (0 * a_init_i) + (1 * a_init_x) + (1 * a_init_ex) + (1 * a_init_dxc)
		(-0 * a_lp_i) + (-0 * a_lp_x) + (-0 * a_lp_ex) + (-1 * a_lp_dxc) >= (0 * a_init_i) + (-1 * a_init_x) + (-1 * a_init_ex) + (-1 * a_init_dxc)
		(-0 * a_lp_i) + (-0 * a_lp_x) + (-0 * a_lp_ex) + (-1 * a_lp_dxc) >= (0 * a_init_i) + (-1 * a_init_x) + (-1 * a_init_ex) + (-1 * a_init_dxc)
		exp((0 * a_lp_i) + (0 * a_lp_x) + (0 * a_lp_ex) + (0 * a_lp_dxc) + b_lp) >= 0.5*exp((1 * a_init_i) + (0.0500001 * a_init_x) + (0 * a_init_ex) + (0 * a_init_dxc) + b_init) + 0.5*exp((1 * a_init_i) + (-0.05 * a_init_x) + (0 * a_init_ex) + (0 * a_init_dxc) + b_init)
		exp((59 * a_lp_i) + (292.051 * a_lp_x) + (295 * a_lp_ex) + (0 * a_lp_dxc) + b_lp) >= 0.5*exp((60 * a_init_i) + (292.101 * a_init_x) + (295 * a_init_ex) + (0 * a_init_dxc) + b_init) + 0.5*exp((60 * a_init_i) + (292.001 * a_init_x) + (295 * a_init_ex) + (0 * a_init_dxc) + b_init)
		exp((59 * a_lp_i) + (297.951 * a_lp_x) + (295 * a_lp_ex) + (0 * a_lp_dxc) + b_lp) >= 0.5*exp((60 * a_init_i) + (298.001 * a_init_x) + (295 * a_init_ex) + (0 * a_init_dxc) + b_init) + 0.5*exp((60 * a_init_i) + (297.901 * a_init_x) + (295 * a_init_ex) + (0 * a_init_dxc) + b_init)
		exp((59 * a_lp_i) + (-292.049 * a_lp_x) + (-295 * a_lp_ex) + (0 * a_lp_dxc) + b_lp) >= 0.5*exp((60 * a_init_i) + (-291.999 * a_init_x) + (-295 * a_init_ex) + (0 * a_init_dxc) + b_init) + 0.5*exp((60 * a_init_i) + (-292.099 * a_init_x) + (-295 * a_init_ex) + (0 * a_init_dxc) + b_init)
		exp((59 * a_lp_i) + (-297.949 * a_lp_x) + (-295 * a_lp_ex) + (0 * a_lp_dxc) + b_lp) >= 0.5*exp((60 * a_init_i) + (-297.899 * a_init_x) + (-295 * a_init_ex) + (0 * a_init_dxc) + b_init) + 0.5*exp((60 * a_init_i) + (-297.999 * a_init_x) + (-295 * a_init_ex) + (0 * a_init_dxc) + b_init)
		(0 * a_init_i) + (0 * a_init_x) + (0 * a_init_ex) + (1 * a_init_dxc) >= (0 * a_la_i) + (0 * a_la_x) + (0 * a_la_ex) + (1 * a_la_dxc)
		(-0 * a_init_i) + (-0 * a_init_x) + (-0 * a_init_ex) + (-1 * a_init_dxc) >= (0 * a_la_i) + (0 * a_la_x) + (0 * a_la_ex) + (-1 * a_la_dxc)
		exp((60 * a_init_i) + (297 * a_init_x) + (300 * a_init_ex) + (0 * a_init_dxc) + b_init) >= 1*exp((60 * a_la_i) + (297 * a_la_x) + (300 * a_la_ex) + (0 * a_la_dxc) + b_la)
		exp((60 * a_init_i) + (303 * a_init_x) + (300 * a_init_ex) + (0 * a_init_dxc) + b_init) >= 1*exp((60 * a_la_i) + (303 * a_la_x) + (300 * a_la_ex) + (0 * a_la_dxc) + b_la)
		exp((60 * a_init_i) + (-297 * a_init_x) + (-300 * a_init_ex) + (0 * a_init_dxc) + b_init) >= 1*exp((60 * a_la_i) + (-297 * a_la_x) + (-300 * a_la_ex) + (0 * a_la_dxc) + b_la)
		exp((60 * a_init_i) + (-303 * a_init_x) + (-300 * a_init_ex) + (0 * a_init_dxc) + b_init) >= 1*exp((60 * a_la_i) + (-303 * a_la_x) + (-300 * a_la_ex) + (0 * a_la_dxc) + b_la)
		exp((60 * a_la_i) + (303 * a_la_x) + (300 * a_la_ex) + (0 * a_la_dxc) + b_la) >= 0
		exp((60 * a_la_i) + (298 * a_la_x) + (300 * a_la_ex) + (0 * a_la_dxc) + b_la) >= 0
		exp((60 * a_la_i) + (-302 * a_la_x) + (-300 * a_la_ex) + (0 * a_la_dxc) + b_la) >= 0
		exp((60 * a_la_i) + (-297 * a_la_x) + (-300 * a_la_ex) + (0 * a_la_dxc) + b_la) >= 0
		(0 * a_la_i) + (0 * a_la_x) + (0 * a_la_ex) + (1 * a_la_dxc) >= 0
		(-0 * a_la_i) + (-0 * a_la_x) + (-0 * a_la_ex) + (-1 * a_la_dxc) >= 0
		exp((60 * a_la_i) + (297 * a_la_x) + (300 * a_la_ex) + (0 * a_la_dxc) + b_la) >= 1
		exp((60 * a_la_i) + (298 * a_la_x) + (300 * a_la_ex) + (0 * a_la_dxc) + b_la) >= 1
		exp((60 * a_la_i) + (-302 * a_la_x) + (-300 * a_la_ex) + (0 * a_la_dxc) + b_la) >= 1
		exp((60 * a_la_i) + (-303 * a_la_x) + (-300 * a_la_ex) + (0 * a_la_dxc) + b_la) >= 1
cvx_end
et=cputime-st


 %running time is  0.00250401  second!
