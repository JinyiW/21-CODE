st=cputime;
cvx_begin
	variable a_init_i
	variable a_init_t
	variable b_init
	variable a_la_i
	variable a_la_t
	variable b_la
	minimize(0*a_init_i + 0*a_init_t + b_init)
	subject to
		exp((0 * a_init_i) + (0 * a_init_t) + b_init) >= 1*exp((1 * a_la_i) + (1 * a_la_t) + b_la)
		exp((0 * a_init_i) + (100 * a_init_t) + b_init) >= 1*exp((1 * a_la_i) + (101 * a_la_t) + b_la)
		exp((1 * a_init_i) + (0 * a_init_t) + b_init) >= 0.200001*exp((1 * a_la_i) + (1 * a_la_t) + b_la) + 0.800001*exp((2 * a_la_i) + (1 * a_la_t) + b_la)
		exp((1 * a_init_i) + (100 * a_init_t) + b_init) >= 0.200001*exp((1 * a_la_i) + (101 * a_la_t) + b_la) + 0.800001*exp((2 * a_la_i) + (101 * a_la_t) + b_la)
		exp((2 * a_init_i) + (0 * a_init_t) + b_init) >= 0.400001*exp((2 * a_la_i) + (1 * a_la_t) + b_la) + 0.600001*exp((3 * a_la_i) + (1 * a_la_t) + b_la)
		exp((2 * a_init_i) + (100 * a_init_t) + b_init) >= 0.400001*exp((2 * a_la_i) + (101 * a_la_t) + b_la) + 0.600001*exp((3 * a_la_i) + (101 * a_la_t) + b_la)
		exp((3 * a_init_i) + (0 * a_init_t) + b_init) >= 0.600001*exp((3 * a_la_i) + (1 * a_la_t) + b_la) + 0.400001*exp((4 * a_la_i) + (1 * a_la_t) + b_la)
		exp((3 * a_init_i) + (100 * a_init_t) + b_init) >= 0.600001*exp((3 * a_la_i) + (101 * a_la_t) + b_la) + 0.400001*exp((4 * a_la_i) + (101 * a_la_t) + b_la)
		exp((4 * a_init_i) + (0 * a_init_t) + b_init) >= 0.800001*exp((4 * a_la_i) + (1 * a_la_t) + b_la) + 0.200001*exp((5 * a_la_i) + (1 * a_la_t) + b_la)
		exp((4 * a_init_i) + (100 * a_init_t) + b_init) >= 0.800001*exp((4 * a_la_i) + (101 * a_la_t) + b_la) + 0.200001*exp((5 * a_la_i) + (101 * a_la_t) + b_la)
		exp((5 * a_init_i) + (0 * a_init_t) + b_init) >= 0
		exp((5 * a_init_i) + (100 * a_init_t) + b_init) >= 0
		exp((5 * a_la_i) + (0 * a_la_t) + b_la) >= 1*exp((5 * a_init_i) + (0 * a_init_t) + b_init)
		exp((5 * a_la_i) + (100 * a_la_t) + b_la) >= 1*exp((5 * a_init_i) + (100 * a_init_t) + b_init)
		exp((0 * a_la_i) + (100 * a_la_t) + b_la) >= 1*exp((0 * a_init_i) + (100 * a_init_t) + b_init)
		exp((0 * a_la_i) + (0 * a_la_t) + b_la) >= 1*exp((0 * a_init_i) + (0 * a_init_t) + b_init)
		exp((5 * a_la_i) + (101 * a_la_t) + b_la) >= 1
		exp((0 * a_la_i) + (101 * a_la_t) + b_la) >= 1
cvx_end
et=cputime-st


 %running time is  0.00207901  second!
