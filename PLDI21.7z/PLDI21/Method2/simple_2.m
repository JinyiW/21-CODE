st=cputime;
cvx_begin
	variable a_init_x
	variable a_init_i
	variable b_init
	variable a_lb_x
	variable a_lb_i
	variable b_lb
	minimize(0*a_init_x + 0*a_init_i + b_init)
	subject to
		exp((0 * a_init_x) + (0 * a_init_i) + b_init) >= 0.5*exp((0 * a_init_x) + (1 * a_init_i) + b_init) + 0.5*exp((1 * a_init_x) + (1 * a_init_i) + b_init)
		exp((500 * a_init_x) + (500 * a_init_i) + b_init) >= 0.5*exp((500 * a_init_x) + (501 * a_init_i) + b_init) + 0.5*exp((501 * a_init_x) + (501 * a_init_i) + b_init)
		exp((0 * a_init_x) + (500 * a_init_i) + b_init) >= 0.5*exp((0 * a_init_x) + (501 * a_init_i) + b_init) + 0.5*exp((1 * a_init_x) + (501 * a_init_i) + b_init)
		exp((501 * a_init_x) + (501 * a_init_i) + b_init) >= 1*exp((501 * a_lb_x) + (501 * a_lb_i) + b_lb)
		exp((0 * a_init_x) + (501 * a_init_i) + b_init) >= 1*exp((0 * a_lb_x) + (501 * a_lb_i) + b_lb)
		exp((225 * a_lb_x) + (501 * a_lb_i) + b_lb) >= 1
		exp((0 * a_lb_x) + (501 * a_lb_i) + b_lb) >= 1
		exp((501 * a_lb_x) + (501 * a_lb_i) + b_lb) >= 0
		exp((225 * a_lb_x) + (501 * a_lb_i) + b_lb) >= 0
cvx_end
et=cputime-st


 %running time is  0.00145501  second!
