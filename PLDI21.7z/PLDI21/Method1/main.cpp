#include<time.h>
#include <bits/stdc++.h>
using namespace std;

const int MAX_BUF = 65536;
const int MAX_VAR_NAME_SIZE = 100;

int n_variable;
int n_sample_variable;
int n_cir_location;
int n_sq_location;

int n_y_variable = 0;

double Epsilon = 1e-6;
double Delta = 1.0;

vector <double> var_id_to_init_value;
map <string, double> var_name_to_init_value;
vector <string> var_id_to_name;
map <string, int> var_name_to_id;

vector <string> sample_var_id_to_name;
map <string, int> sample_var_name_to_id;
// Uniform(a, b)
vector <pair<double, double> > sample_var_id_to_value;
// Expectation
vector <double> sample_var_id_to_E;

vector <string> cir_id_to_name;
map <string, int> cir_name_to_id;

vector <string> sq_id_to_name;
map <string, int> sq_name_to_id;

// sq id to previous cir id
vector <int> sq_pre;

struct cond {
    // 1 -- and, 2 -- or
    int operation_type;
    // be simple. sub_conds contains 2 elements if !is_leaf
    vector <cond *> sub_conds;

    // coef[0] * var[0] + coef[1] * var[1] + ... + coef[n-1] * var[n-1] <= coef[n]
    bool is_leaf;
    vector <double> coef;

    bool is_bool, f;

    cond() {}
    cond(bool _f) : operation_type(0), is_leaf(1), is_bool(1), f(_f) {}
    cond(const cond & a) : operation_type(a.operation_type),
                           is_leaf(a.is_leaf),
                           is_bool(a.is_bool),
                           f(a.f) {

        if (!is_leaf && operation_type) {
            sub_conds.resize(a.sub_conds.size());
            for (int i=0;i<a.sub_conds.size();i++) sub_conds[i]=a.sub_conds[i];
        }
        if (is_leaf && !is_bool) {
            coef.resize(n_variable+1);
            for (int i=0;i<n_variable+1;i++) coef[i] = a.coef[i];
        }
    }

    friend ostream & operator<<(ostream &out, cond & a) ;
} ;

ostream & operator<<(ostream &out, cond & a) {
    if (a.is_leaf) {
        if (a.is_bool) out << (a.f?"true":"false");
        else {
            bool start = true;
            for (int i=0;i<n_variable;i++) if (a.coef[i]) {
                    if (!start && a.coef[i] > 0) out << "+";
                    if (abs(a.coef[i] - 1) > 1e-8) {
                        if (abs(a.coef[i] + 1) > 1e-8) out << a.coef[i] << "*";
                        else out << "-";
                    }
                    out << var_id_to_name[i];
                    start = false;
                }
            if (start) out << "0";
            out << " <= " << a.coef[n_variable];
        }
        return out;
    }
    for (int i=0;i<a.sub_conds.size();i++) {
        if (i>0) {
            if (a.operation_type == 1) out << " and ";
            else if (a.operation_type == 2) out << " or ";
        }
        out << "(" << *a.sub_conds[i] << ")";
    }
    return out;
}

// p : double
// upd : vector<vector<double> >
// phi_trans id : int
vector<vector<tuple<double, vector<vector<double> >, int> > > p_trans;

// phi : cond *
// p_trans id : int
vector<vector<pair<cond*, int> > > phi_trans;

// poly : cond *
vector <cond*> cir_poly, sq_poly;

cond * cond_and(cond * a, cond * b) {
    cond * x;
    // one of a, b is true/false
    if (a->is_leaf && a->is_bool) {
        if (a->f) return new cond(*b);
        else return a;
    }
    if (b->is_leaf && b->is_bool) {
        if (b->f) return new cond(*a);
        else return b;
    }

    x = new cond;
    x->is_leaf = 0;
    x->operation_type = 1;
    x->sub_conds.push_back(a);
    x->sub_conds.push_back(b);
    return x;
}

cond * cond_or(cond * a, cond * b) {
    cond * x;
    // one of a, b is true/false
    if (a->is_leaf && a->is_bool) {
        if (!a->f) return new cond(*b);
        else return a;
    }
    if (b->is_leaf && b->is_bool) {
        if (!b->f) return new cond(*a);
        else return b;
    }

    x = new cond;
    x->is_leaf = 0;
    x->operation_type = 2;
    x->sub_conds.push_back(a);
    x->sub_conds.push_back(b);
    return x;
}


cond * cond_normal(cond * a) {
    if (a->is_leaf) return a;
    cond * x;
    if (a->operation_type == 1) {
        assert(a->sub_conds.size() == 2);
        cond * ch1 = cond_normal(a->sub_conds[0]);
        cond * ch2 = cond_normal(a->sub_conds[1]);
        if (!ch1->is_leaf && ch1->operation_type == 2) {
            assert(ch1->sub_conds.size() == 2);
            cond * new_ch1 = cond_and(ch1->sub_conds[0], ch2);
            cond * new_ch2 = cond_and(ch1->sub_conds[1], ch2);
            new_ch1 = cond_normal(new_ch1);
            new_ch2 = cond_normal(new_ch2);
            x = cond_or(new_ch1, new_ch2);
        } else if (!ch2->is_leaf && ch2->operation_type == 2) {
            assert(ch2->sub_conds.size() == 2);
            cond * new_ch1 = cond_and(ch1, ch2->sub_conds[0]);
            cond * new_ch2 = cond_and(ch1, ch2->sub_conds[1]);
            new_ch1 = cond_normal(new_ch1);
            new_ch2 = cond_normal(new_ch2);
            x = cond_or(new_ch1, new_ch2);
        } else {
            x = cond_and(ch1, ch2);
        }
    } else if (a->operation_type == 2) {
        assert(a->sub_conds.size() == 2);
        cond * ch1 = cond_normal(a->sub_conds[0]);
        cond * ch2 = cond_normal(a->sub_conds[1]);
        x = cond_or(ch1, ch2);
    } else assert(0);
    return x;
}


void print_upd(vector<vector<double> > upd) {
    for (int i=0;i<n_variable;i++) {
        cout << var_id_to_name[i] << " := ";
        bool start = true;
        for (int j=0;j<n_variable;j++) {
            if (abs(upd[i][j]) > 1e-8) {
                if (!start && upd[i][j]>0) cout << "+";
                cout << upd[i][j] << "*" << var_id_to_name[j];
                start = false;
            }
        }
        cout << "+";
        start = true;
        for (int j=0;j<n_sample_variable;j++) {
            if (abs(upd[i][n_variable+j]) > 1e-8) {
                if (!start && upd[i][n_variable+j]>0) cout << "+";
                cout << upd[i][n_variable+j] << "*" << sample_var_id_to_name[j];
                start = false;
            }
        }
        if (!start) cout << "0";
        if (abs(upd[i][n_variable]) > 1e-8) {
            if (!start && upd[i][n_variable]>0) cout << "+";
            cout << upd[i][n_variable];
        }
        cout << endl;
    }
}

void get_invariant() {
    //cir_poly.resize(n_cir_location + 1);
    sq_poly.resize(n_sq_location + 1);

    for (int i=0;i<n_cir_location;i++) {
        for (int j=0;j<phi_trans[i].size();j++) {
            int id = phi_trans[i][j].second;
            cond * phi_poly = phi_trans[i][j].first;
//            cout << "before normalize : " << *phi_poly << endl;
            sq_poly[id] = cond_normal(cond_and(phi_poly, cir_poly[i]));
//            cout << "after normalize : " << *sq_poly[id] << endl;
        }
    }

    sq_pre.resize(n_sq_location + 1);
    for (int i=0;i<n_cir_location;i++) {
        for (int j=0;j<phi_trans[i].size();j++) {
            int id = phi_trans[i][j].second;
            sq_pre[id] = i;
        }
    }
}

void get_ineq() {

    // (C1)
    cout << "(C1)\n";
    for (int i=0;i<n_variable;i++) {
        cout << "a_init_" << var_id_to_name[i] << "*" << var_id_to_init_value[i] << "+";
    }
    cout << "b_init <= 0" << endl;

    // (C2)
    cout << "(C2)\n";
    int id;
    if (cir_name_to_id.find("f") == cir_name_to_id.end()) id = cir_name_to_id["-1"];
    else id = cir_name_to_id["f"];

    cout << "\\forall " << *cir_poly[id] << ". ";
    for (int i=0;i<n_variable;i++) {
        cout << "a_" << cir_id_to_name[id] << "_" << var_id_to_name[i] << "*" << var_id_to_name[i] << "+";
    }
    cout << "b_" << cir_id_to_name[id] << " >= 0" << endl;

    // (C3) for each transition
    cout << "(C3)\n";
    for (int i=0;i<n_sq_location;i++) {
//        cout << "i = [" << i << "], cond = [" << *sq_poly[i] << "]" << endl;
        cout << "\\forall " << *sq_poly[i] << ". \\eta_" << cir_id_to_name[sq_pre[i]] << "(";
        for (int j=0;j<n_variable;j++) cout << var_id_to_name[j] << ",)"[j==n_variable-1];
        cout << " - \\epsilon >= ";

        for (int j=0;j<p_trans[i].size();j++) {
            double p = get<0>(p_trans[i][j]);
            vector<vector<double> > upd = get<1>(p_trans[i][j]);
            int id = get<2>(p_trans[i][j]);
            if (abs(p-1)>1e-8) cout << p << "*";

            string name = cir_id_to_name[id];

            cout << "E[\\eta_" << cir_id_to_name[id] << "(";
            for (int k=0;k<n_variable;k++) {
                bool start = true;
                for (int kk=0;kk<n_variable+n_sample_variable;kk++) if (abs(upd[k][kk])>1e-8) {
                        if (!start && upd[k][kk]>0) cout << "+";
                        if (abs(upd[k][kk]-1)>1e-8) cout << upd[k][kk] << "*";
                        if (kk<n_variable) cout << var_id_to_name[kk];
                        else cout << sample_var_id_to_name[kk-n_variable];
                        start = false;
                    }
                if (!start && abs(upd[k][n_variable+n_sample_variable])>1e-8 && upd[k][n_variable+n_sample_variable]>0) cout << "+";
                if (abs(upd[k][n_variable+n_sample_variable])>1e-8) cout << upd[k][n_variable+n_sample_variable];
                if (k<n_variable-1) cout << ",";
            }
            cout << ")]";

            if (j<p_trans[i].size()-1) cout << " + ";
        }

        cout << endl;
    }


    // (C4) for each transition and 1 <= j <= k
    cout << "(C4)\n";
    for (int i=0;i<n_sq_location;i++) {
//        cout << "i = [" << i << "], cond = [" << *sq_poly[i] << "]" << endl;

        for (int j=0;j<p_trans[i].size();j++) {
            double p = get<0>(p_trans[i][j]);
            vector<vector<double> > upd = get<1>(p_trans[i][j]);
            int id = get<2>(p_trans[i][j]);

            cout << "\\forall " << *sq_poly[i] << " and (";
            for (int k=0;k<n_sample_variable;k++) {
                cout << sample_var_id_to_value[k].first << " <= " << sample_var_id_to_name[k] << " and ";
                cout << sample_var_id_to_name[k] << " <= " << sample_var_id_to_value[k].second;
                if (k < n_sample_variable-1) cout << " and ";
            }
            cout << "). ";

            cout << "\\varbeta <= ";

            string name = cir_id_to_name[id];

            cout << "\\eta_" << cir_id_to_name[id] << "(";
            for (int k=0;k<n_variable;k++) {
                bool start = true;
                for (int kk=0;kk<n_variable+n_sample_variable;kk++) if (abs(upd[k][kk])>1e-8) {
                        if (!start && upd[k][kk]>0) cout << "+";
                        if (abs(upd[k][kk]-1)>1e-8) cout << upd[k][kk] << "*";
                        if (kk<n_variable) cout << var_id_to_name[kk];
                        else cout << sample_var_id_to_name[kk-n_variable];
                        start = false;
                    }
                if (!start && abs(upd[k][n_variable+n_sample_variable])>1e-8 && upd[k][n_variable+n_sample_variable]>0) cout << "+";
                if (abs(upd[k][n_variable+n_sample_variable])>1e-8) cout << upd[k][n_variable+n_sample_variable];
                if (k<n_variable-1) cout << ",";
            }
            cout << ") - ";

            cout << "\\eta_" << cir_id_to_name[sq_pre[i]] << "(";
            for (int k=0;k<n_variable;k++) cout << var_id_to_name[k] << ",)"[k==n_variable-1];
            cout << " <= \\varbeta + \\Delta" << endl;

        }

    }

}

void get_cond_ineq(cond * c, vector <vector<double> > & A, vector <double> & b) {
    if (c->is_leaf) {
        if (c->is_bool) {
            // ? is it correct
            if (c->f) {
                int now = A.size();
                A.resize(now+1);
                A[now].resize(n_variable);
                b.resize(now+1);
                for (int i=0;i<n_variable;i++) A[now][i] = 0;
                b[now] = 0;
            } else return ;
        } else {
            int now = A.size();
            A.resize(now+1);
            A[now].resize(n_variable);
            b.resize(now+1);
            for (int i=0;i<n_variable;i++) {
                A[now][i] = c->coef[i];
            }
            b[now] = c->coef[n_variable];
        }
        return ;
    }
    assert(c->sub_conds.size() == 2);
    assert(c->operation_type == 1);
    get_cond_ineq(c->sub_conds[0], A, b);
    get_cond_ineq(c->sub_conds[1], A, b);
}
void _get_C3_ineq(cond * c, int cir_loc_id, int sq_loc_id, stringstream & out) {
    if (!c->is_leaf && c->operation_type==2) {
        assert(c->sub_conds.size() == 2);
        _get_C3_ineq(c->sub_conds[0], cir_loc_id, sq_loc_id, out);
        _get_C3_ineq(c->sub_conds[1], cir_loc_id, sq_loc_id, out);
    } else {
        vector <vector<double> > vA;
        vector <double> vb;
        get_cond_ineq(c, vA, vb);
        if (vA.size() == 0) return ;
        assert(vA[0].size() == n_variable);

        int m = vA.size();
        for (int i=0;i<n_variable;i++) {
            out << "\t\t";
            // A^T * y = c
            for (int j=0;j<m;j++) {
                out << "(" << vA[j][i] << "*" << "y_" << n_y_variable+j << ")";
                if (j < m-1) out << " + ";
            }
            out << " == (";
            bool not_start = true;
            for (int j=0;j<p_trans[sq_loc_id].size();j++) {
                double p = get<0>(p_trans[sq_loc_id][j]);
                vector<vector<double> > upd = get<1>(p_trans[sq_loc_id][j]);
                int id = get<2>(p_trans[sq_loc_id][j]);
                if (not_start) not_start = false;
                else out << " + ";
                out << p << "*(";
                for (int k=0;k<n_variable;k++) {
                    out << "(" << upd[i][k] << "*a_" << cir_id_to_name[id] << "_" << var_id_to_name[k] << ")";
                    if (k<n_variable-1) out << "+";
                }
                out << ")";
            }
            if (not_start) out << "0";
            out << ") - a_" << cir_id_to_name[cir_loc_id] << "_" << var_id_to_name[i] << "\n";
        }

        // b^T * y <= d
        out << "\t\t";
        for (int j=0;j<vb.size();j++) {
            out << "(" << vb[j] << "*" << "y_" << n_y_variable+j << ")";
            if (j<vb.size()-1) out << " + ";
        }
        out << " <= ";
        out << "b_" << cir_id_to_name[cir_loc_id] << " - epsilon - (";
        bool not_start = true;
        for (int j=0;j<p_trans[sq_loc_id].size();j++) {
            double p = get<0>(p_trans[sq_loc_id][j]);
            vector<vector<double> > upd = get<1>(p_trans[sq_loc_id][j]);
            int id = get<2>(p_trans[sq_loc_id][j]);

            if (not_start) not_start = false;
            else out << " + ";
            out << p << "*(";
            for (int i=0;i<n_variable;i++) {
                double tmp = upd[i][n_variable+n_sample_variable];
                for (int j=0;j<n_sample_variable;j++) tmp += upd[i][n_variable+j] * sample_var_id_to_E[j];
                out << "(" << tmp << "*a_" << cir_id_to_name[id] << "_" << var_id_to_name[i] << ")";
                out << "+";
            }
            out << "b_" << cir_id_to_name[id] << ")";
        }
        if (not_start) out << "0";
        out << ")\n";

        n_y_variable += m;
    }
}
void _get_C4_ineq(cond * c, int cir_loc_id, int sq_loc_id, stringstream & out) {
    if (!c->is_leaf && c->operation_type==2) {
        assert(c->sub_conds.size() == 2);
        _get_C4_ineq(c->sub_conds[0], cir_loc_id, sq_loc_id, out);
        _get_C4_ineq(c->sub_conds[1], cir_loc_id, sq_loc_id, out);
    } else {
//        cout << "c = [" << *c << "]" << endl;
        vector <vector<double> > vA;
        vector <double> vb;
        get_cond_ineq(c, vA, vb);
        if (vA.size() == 0) return ;
        assert(vA[0].size() == n_variable);
        int m = vA.size();
//        cout << "vA = \n";
//        for (int i=0;i<m;i++) {
//            for (int j=0;j<n_variable;j++) cout << vA[i][j] << " ";
//            cout << endl;
//        }
//        cout << "vb = \n";
//        for (int i=0;i<m;i++) cout << vb[i] << " "; cout << endl;

        for (int j=0;j<p_trans[sq_loc_id].size();j++) {
            double p = get<0>(p_trans[sq_loc_id][j]);
            vector<vector<double> > upd = get<1>(p_trans[sq_loc_id][j]);
            int id = get<2>(p_trans[sq_loc_id][j]);

            // A^T * y = c
            // -- variables
            for (int i=0;i<n_variable;i++) {
                // ---- beta <= dst - src
                out << "\t\t";
                for (int j=0;j<m;j++) {
                    out << "(" << vA[j][i] << "*" << "y_" << n_y_variable+j << ")";
                    if (j < m-1) out << " + ";
                }
                out << " == a_" << cir_id_to_name[cir_loc_id] << "_" << var_id_to_name[i] << " - (";
                for (int k=0;k<n_variable;k++) {
                    out << "(" << upd[i][k] << "*a_" << cir_id_to_name[id] << "_" << var_id_to_name[k] << ")";
                    if (k<n_variable-1) out << "+";
                }
                out << ")\n";

                // ---- dst - src <= beta + Delta
                out << "\t\t";
                for (int j=0;j<m;j++) {
                    out << "(" << vA[j][i] << "*" << "y_" << n_y_variable+m+2*n_sample_variable+j << ")";
                    if (j < m-1) out << " + ";
                }
                out << " == (";
                for (int k=0;k<n_variable;k++) {
                    out << "(" << upd[i][k] << "*a_" << cir_id_to_name[id] << "_" << var_id_to_name[k] << ")";
                    if (k<n_variable-1) out << "+";
                }
                out << ") - a_" << cir_id_to_name[cir_loc_id] << "_" << var_id_to_name[i] << "\n";
            }
            // -- sample variables
            for (int i=0;i<n_sample_variable;i++) {
                // ---- beta <= dst - src
                out << "\t\ty_" << n_y_variable+m+2*i << " - y_" << n_y_variable+m+2*i+1;
                out << " ==  - (";
                for (int k=0;k<n_variable;k++) {
                    out << "(" << upd[k][n_variable+i] << "*a_" << cir_id_to_name[id] << "_" << var_id_to_name[k] << ")";
                    if (k<n_variable-1) out << "+";
                }
                out << ")\n";

                // ---- dst - src <= beta + Delta
                out << "\t\ty_" << n_y_variable+2*m+2*n_sample_variable+2*i << " - y_" << n_y_variable+2*m+2*n_sample_variable+2*i+1;
                out << " == ";
                for (int k=0;k<n_variable;k++) {
                    out << "(" << upd[k][n_variable+i] << "*a_" << cir_id_to_name[id] << "_" << var_id_to_name[k] << ")";
                    if (k<n_variable-1) out << "+";
                }
                out << "\n";
            }

            // b^T * y <= d
            // ---- beta <= dst - src
            out << "\t\t";
            for (int j=0;j<m;j++) {
                out << "(" << vb[j] << "*" << "y_" << n_y_variable+j << ")";
                if (j<m-1 || n_sample_variable>0) out << " + ";
            }
            for (int j=0;j<n_sample_variable;j++) {
                out << "(" << sample_var_id_to_value[j].second << "*y_" << n_y_variable+m+2*j << ")";
                out << " + (" << -sample_var_id_to_value[j].first << "*y_" << n_y_variable+m+2*j+1 << ")";
                if (j<n_sample_variable-1) out << " + ";
            }
            out << " <= ";
            for (int i=0;i<n_variable;i++) {
                out << "(" << upd[i][n_variable+n_sample_variable] << "*a_" << cir_id_to_name[id] << "_" << var_id_to_name[i] << ")";
                out << "+";
            }
            out << "b_" << cir_id_to_name[id];
            out << " - b_" << cir_id_to_name[cir_loc_id] << " - varbeta\n";

            // ---- dst - src <= beta + Delta
            out << "\t\t";
            for (int j=0;j<m;j++) {
                out << "(" << vb[j] << "*" << "y_" << n_y_variable+m+2*n_sample_variable+j << ")";
                if (j<m-1 || n_sample_variable>0) out << " + ";
            }
            for (int j=0;j<n_sample_variable;j++) {
                out << "(" << sample_var_id_to_value[j].second << "*y_" << n_y_variable+2*m+2*n_sample_variable+2*j << ")";
                out << " + (" << -sample_var_id_to_value[j].first << "*y_" << n_y_variable+2*m+2*n_sample_variable+2*j+1 << ")";
                if (j<n_sample_variable-1) out << " + ";
            }
            out << " <= varbeta + " << Delta << " + b_" << cir_id_to_name[cir_loc_id] << " - (";
            for (int i=0;i<n_variable;i++) {
                out << "(" << upd[i][n_variable+n_sample_variable] << "*a_" << cir_id_to_name[id] << "_" << var_id_to_name[i] << ")";
                out << "+";
            }
            out << "b_" << cir_id_to_name[id] << ")\n";

            n_y_variable += 2*(m+2*n_sample_variable);
        }
    }
}
void _get_C2_ineq(cond * c, stringstream & out) {
    if (!c->is_leaf && c->operation_type == 2) {
        _get_C2_ineq(c->sub_conds[0], out);
        _get_C2_ineq(c->sub_conds[1], out);
    } else {
        vector <vector <double> > A;
        vector <double> b;
        get_cond_ineq(c, A, b);
        int m = A.size();
        // A^T y = c
        for (int i=0;i<n_variable;i++) {
            out << "\t\t";
            for (int j=0;j<m;j++) {
                out << "(" << A[j][i] << "*y_" << n_y_variable + j << ")";
                if (j<m-1) out << " + ";
            }
            out << " == -a_f_" << var_id_to_name[i] << "\n";
        }

        // b^T y <= d
        out << "\t\t";
        for (int i=0;i<m;i++) {
            out << b[i] << "*y_" << n_y_variable + i;
            if (i<m-1) out << " + ";
        }
        out << " <= b_f\n";

        n_y_variable += m;
    }
}
void get_C1_ineq(stringstream & out) {
    out << "\t\t";
    for (int i=0;i<n_variable;i++) {
        out << "(" << var_id_to_init_value[i] << " * a_init_" << var_id_to_name[i] << ") + ";
    }
    out << "b_init <= 0\n";
}
void get_C2_ineq(stringstream & out) {
    int id;
    if (cir_name_to_id.find("f") == cir_name_to_id.end()) id = cir_name_to_id["-1"];
    else id = cir_name_to_id["f"];
    _get_C2_ineq(cir_poly[id], out);
}
void get_C3_ineq(stringstream & out) {
    for (int i=0;i<n_sq_location;i++) {
//        cout << "i = [" << i << "], cond = [" << *sq_poly[i] << "]" << endl;
        cond * x = sq_poly[i];
        _get_C3_ineq(x, sq_pre[i], i, out);
    }
}
void get_C4_ineq(stringstream & out) {
    for (int i=0;i<n_sq_location;i++) {
//        cout << "i = [" << i << "], cond = [" << *sq_poly[i] << "]" << endl;
        cond * x = sq_poly[i]; //cir_poly[sq_pre[i]];
        _get_C4_ineq(x, sq_pre[i], i, out);
    }
}
void get_decomposition() {
    stringstream constraints;

    get_C1_ineq(constraints);
//    cout << "C1 end" << endl;

    get_C2_ineq(constraints);
//    cout << "C2 end" << endl;

    get_C3_ineq(constraints);
//    cout << "C3 end" << endl;

    get_C4_ineq(constraints);
//    cout << "C4 end" << endl;

    // print
    cout << "function [result] = calcu(epsilon)\n";
    cout << "cvx_begin\n";

    // variables
    for (int i=0;i<n_cir_location;i++) {
        for (int j=0;j<n_variable;j++) {
            cout << "\tvariable a_" << cir_id_to_name[i] << "_" << var_id_to_name[j] << "\n";
        }
        cout << "\tvariable b_" << cir_id_to_name[i] << "\n";
    }
    for (int i=0;i<n_y_variable;i++) {
        cout << "\tvariable y_" << i << "\n";
    }
    // cout << "\tvariable epsilon\n";
    cout << "\tvariable varbeta\n";
    // cout << "\tvariable Delta\n";

    // objective function
    cout << "\tminimize(" << 8/(Delta*Delta) << "*epsilon*(";
    for (int i=0;i<n_variable;i++) {
        cout << var_id_to_init_value[i] << "*a_init_" << var_id_to_name[i] << " + ";
    }
    cout << "b_init))\n";
    cout << "\tsubject to\n";

    // constraints
    for (int i=0;i<n_y_variable;i++) {
        cout << "\t\ty_" << i << " >= 0\n";
    }
    cout << constraints.str();
    cout << "cvx_end" << endl;

    cout << "\tresult = (" << 8/(Delta*Delta) << "*epsilon*(";
    for (int i=0;i<n_variable;i++) {
        cout << var_id_to_init_value[i] << "*a_init_" << var_id_to_name[i] << " + ";
    }
    cout << "b_init));\n";
    for (int i=0;i<n_variable;i++) {
        cout << "a_init_" << var_id_to_name[i] << endl;
    }
    cout << "b_init\n";
    cout << "epsilon\n";
    // cout << "stochastic(epsilon,varbeta,result/8/epsilon)";

}


char * parser_int(char * buf, char * buf_end, char ed, int & num) {
    int f=1, x=0;
    for (;buf!=buf_end;buf++) {
        if (*buf == ed) {buf++; break;}
        if (*buf == '-') f=-1;
        else x = x * 10 + *buf-'0';
    }
    num = f * x;
    return buf;
}

char * parser_loc(char * buf, char * buf_end, const char ed[], int & num, int & op, int & ed_id) {
    int idx = 0, _op = 0;
    for (char * p = buf; p != buf_end; p++, idx++) {
        int f=0;
        for (int j=0;ed[j];j++) {
            if (*p == ed[j]) { buf_end=p+1; idx++; ed_id=j; f=1; break; }
        }
        if (f) break;
        if (*p == '.') _op = 1;
    }
    string name(buf, buf+idx-1);
//    cout << "name = " << name << endl;
    if (_op == 0) {
        if (cir_name_to_id.find(name) == cir_name_to_id.end()) {
            cir_name_to_id[name] = n_cir_location++;
            cir_id_to_name.push_back(name);
            phi_trans.resize(n_cir_location);
            cir_poly.resize(n_cir_location);
        }
        num = cir_name_to_id[name];
    } else {
        if (sq_name_to_id.find(name) == sq_name_to_id.end()) {
            sq_name_to_id[name] = n_sq_location++;
            sq_id_to_name.push_back(name);
            p_trans.resize(n_sq_location);
        }
        num = sq_name_to_id[name];
    }
    op = _op;
    return buf_end;
}
char * parser_prob(char * buf, char * buf_end, char ed, double & p) {
    double x=0, t=1;
    int f=0;
    for (;buf!=buf_end;buf++) {
        if (*buf == ed) {buf++; break;}
        if (*buf != '.' && (*buf < '0' || *buf > '9')) continue;
        if (*buf == '.') f=1;
        else if (f) x = 10*x + *buf-'0', t *= 10;
        else x = 10*x + *buf-'0';
    }
    p = x / t;
    return buf;
}


void _parser_phi_leaf(char * buf, int l, int r, cond * &phi) {
//    cout << "leaf now ["; for (int i=l;i<=r;i++) cout << buf[i]; cout << "]" << endl;
    // check if buf[l..r] is true or false
    static char _tr[10] = "true";
    static char _fa[10] = "false";
    if (r-l+1 == strlen(_tr)) {
        bool f = 1;
        for (int i=l,j=0;i<=r;i++,j++) {
            if (buf[i] != _tr[j]) { f=0; break; }
        }
        if (f) {
            cond * x = new cond;
            x->is_leaf = true;
            x->is_bool = true;
            x->f = true;
            phi = x;
            return ;
        }
    } else if (r-l+1 == strlen(_fa)) {
        bool f = 1;
        for (int i=l,j=0;i<=r;i++,j++) {
            if (buf[i] != _fa[j]) { f=0; break;}
        }
        if (f) {
            cond * x = new cond;
            x->is_leaf = true;
            x->is_bool = true;
            x->f = false;
            phi = x;
            return ;
        }
    }

    // if buf[l..r] isn't true nor false
    double * coef = new double[n_variable + 1];
    for (int i=0;i<n_variable+1;i++) coef[i] = 0;

    double u = 0, t = 0.1;
    int ipart = 1, f = 1, no_number = 1, no_var = 1;
    int dir = 0, lhs = 1;
    for (int i=l;i<=r;i++) {
        if (buf[i] == '-' || buf[i] == '+') {
            if (no_var) {
                coef[n_variable] -= lhs * f * u;
                u=0, t=0.1, f=1, no_number=1;
            }
            if (buf[i] == '-') f = -f;
        } else if (('0' <= buf[i] && buf[i] <= '9') || buf[i] == '.') {
            no_number = 0, no_var = 1;
            if (buf[i] == '.') ipart = 0;
            else {
                if (ipart) u = u * 10 + buf[i]-'0';
                else u = u + (buf[i]-'0')*t, t *= 0.1;
            }
        } else if (buf[i] == '<') {
            assert(i+1<=r && buf[i+1]=='=');
            if (no_var) {
                coef[n_variable] -= lhs * f * u;
                u=0, t=0.1, f=1, no_number=1;
            }
            i++;
            dir = 1;
            lhs = -1;
        } else if (buf[i] == '>') {
            assert(i+1<=r && buf[i+1]=='=');
            if (no_var) {
                coef[n_variable] -= lhs * f * u;
                u=0, t=0.1, f=1, no_number=1;
            }
            i++;
            dir = -1;
            lhs = -1;
        } else {
            no_var = 0;
            int j;
            for (j=i; j<=r && (buf[j]<'0'||buf[j]>'9') && buf[j] != '.' && buf[j] != '-' && buf[j] != '+'
                      && buf[j] != '<' && buf[j] != '>'; j++) ;

            string name(buf+i, buf+j);
//            cout << "name = " << name << endl;
            assert(var_name_to_id.find(name) != var_name_to_id.end());

            int id = var_name_to_id[name];
            coef[id] += lhs * f * (u + no_number);

            u=0, t=0.1, f=1, no_number=1;
            i=j-1;
        }
    }
    if (no_var) {
        coef[n_variable] -= lhs * f * u;
        u=0, t=0.1, f=1, no_number=1;
    }

    assert(dir == 1 || dir == -1);
    for (int i=0;i<n_variable+1;i++) coef[i] *= dir;

    cond * x = new cond;
    x->is_leaf = true;
    x->is_bool = false;
    x->operation_type = 0;
    x->coef.resize(n_variable+1);
    for (int i=0;i<n_variable+1;i++) {
        x->coef[i] = coef[i];
    }

    delete [] coef;

    phi = x;
//    cout << *phi << endl;

}
void _parser_phi(char * buf, int l, int r, int R[], int N[], int dep, cond * &phi) {
//    cout << "now ["; for (int i=l;i<=r;i++) cout << buf[i]; cout << "]" << endl;
    static cond * s[MAX_BUF];
    static int op[MAX_BUF];
    if (dep == 0) {
        for (int i=0;i<MAX_BUF;i++) op[i] = 0;
    }
    for (int i=l;i<=r;i++) {
        if (buf[i] == '(') {
            _parser_phi(buf, i+1, R[i]-1, R, N, dep+1, phi);
            op[dep+1] = 0;
            if (op[dep] == 0) s[dep] = s[dep+1];
            else {
                if (op[dep] == 1) s[dep] = cond_and(s[dep], s[dep+1]);
                else if (op[dep] == 2) s[dep] = cond_or(s[dep], s[dep+1]);
                else assert(0);
            }
            i = R[i];
        } else if (buf[i] == '&') {
            op[dep] = 1;
        } else if (buf[i] == '|') {
            op[dep] = 2;
        } else {
            cond * x = new cond;
            _parser_phi_leaf(buf, i, N[i]-1, x);

            if (op[dep] == 0) s[dep] = x;
            else {
                if (op[dep] == 1) s[dep] = cond_and(s[dep], x);
                else if (op[dep] == 2) s[dep] = cond_or(s[dep], x);
                else assert(0);
            }
            i = N[i]-1;
        }
    }

    if (dep == 0) phi = s[0];
}
char * parser_phi(char * buf, char * buf_end, char ed, cond * &phi) {
    static int s[MAX_BUF], R[MAX_BUF], N[MAX_BUF];
    int s_top = 0, idx = 0;
    for (char * p = buf; p != buf_end; p++, idx++) {
        if (*p == ed) {buf_end = p+1; idx++; break;}
        if (*p == '(') {
            s[s_top++] = idx;
        } else if (*p == ')') {
            R[s[--s_top]] = idx;
        }
        R[idx] = 0;
    }
    if (idx == 0) {
        cond * x = new cond;
        x->is_leaf = x->is_bool = x->f = true;
        x->operation_type = 0;
        phi = x;
        return buf_end;
    }
    assert(s_top == 0);
    for (int i=idx-1,b=idx;i>=0;i--) {
        if (buf[i]=='('||buf[i]==')'||buf[i]=='|'||buf[i]=='&') b=i;
        N[i]=b;
    }

    _parser_phi(buf, 0, idx-1, R, N, 0, phi);
    return buf_end;
}
void _parser_upd(char * buf, int l, int r, vector <vector<double> > & upd) {
//    cout << "now ["; for (int i=l;i<=r;i++) cout << buf[i]; cout << "]" << endl;
    int * id = new int[n_variable+n_sample_variable+1];
    int * vis = new int[n_variable+n_sample_variable+1];
    for (int i=0;i<n_variable+n_sample_variable+1;i++) id[i]=vis[i]=0;
    int lhs = 1, cnt1 = 0, cnt2 = 0;
    for (int i=0;i<n_variable;i++) for (int j=0;j<n_variable+n_sample_variable+1;j++) upd[i][j] = (i==j);
    for (int i=l;i<=r;i++) {
        if (buf[i] == ':' || buf[i] == '=') {
            lhs = 0;
        } else if (buf[i] == '<' || buf[i] == '>' || buf[i] == ',') continue;
        else if (lhs) {
            int j;
            for (j=i; j<=r && buf[j] != ':' && buf[j] != '<' && buf[j] != '>' && buf[j] != ','; j++) ;

            string name(buf+i, buf+j);
//            cout << "name = " << name << endl;
            assert(var_name_to_id.find(name) != var_name_to_id.end());
            id[++cnt1] = var_name_to_id[name];
//            cout << "id[" << cnt1 << "] = " << id[cnt1] << endl;
            assert(vis[id[cnt1]] == 0);
            vis[id[cnt1]] = 1;
            upd[id[cnt1]][id[cnt1]] = 0;
            i = j;
        } else {
            int j;
            for (j=i; j<=r && buf[j] != ':' && buf[j] != '<' && buf[j] != '>' && buf[j] != ','; j++) ;

            int idx = id[++cnt2];

            double u = 0, t = 0.1;
            int ipart = 1, f = 1, no_number = 1, no_var = 1;
            for (int k=i;k<j;k++) {
                if (buf[k] == '-' || buf[k] == '+') {
                    if (no_var) {
                        upd[idx][n_variable+n_sample_variable] += f * u;
                        u=0, t=0.1, f=1, no_number=1;
                    }
                    if (buf[k] == '-') f = -f;
                } else if (('0' <= buf[k] && buf[k] <= '9') || buf[k] == '.') {
                    no_number = 0, no_var = 1;
                    if (buf[k] == '.') ipart = 0;
                    else {
                        if (ipart) u = u * 10 + buf[k]-'0';
                        else u = u + (buf[k]-'0')*t, t *= 0.1;
                    }
                } else {
                    no_var = 0;
                    int kk;
                    for (kk=k; kk<j && (buf[kk]<'0'||buf[kk]>'9') && buf[kk] != '.' && buf[kk] != '+' && buf[kk] != '-'
                               && buf[kk] != ':' && buf[kk] != '<' && buf[kk] != '>' && buf[kk] != ','; kk++) ;

                    string name(buf+k, buf+kk);
//                    cout << "name = [" << name << "]\n";
                    int sub_idx = -1;
                    if (var_name_to_id.find(name) != var_name_to_id.end()) {
                        sub_idx = var_name_to_id[name];
                    } else if (sample_var_name_to_id.find(name) != sample_var_name_to_id.end()) {
                        sub_idx = n_variable + sample_var_name_to_id[name];
                    }
                    assert(sub_idx != -1);

                    upd[idx][sub_idx] += f * (u + no_number);

                    u=0, t=0.1, f=1, no_number=1;
                    k=kk-1;
                }
            }
            if (no_var) {
                upd[idx][n_variable+n_sample_variable] += f * u;
                u=0, t=0.1, f=1, no_number=1;
            }

            i = j;
        }
    }

    assert(lhs == 0 && cnt1 == cnt2);
    delete [] id;
    delete [] vis;
}
char * parser_upd(char * buf, char * buf_end, char ed, vector <vector<double> > & upd) {
    vector <vector<double> > tmp, tmp2;
    tmp.resize(n_variable);
    for (int i=0;i<n_variable;i++) tmp[i].resize(n_variable+n_sample_variable+1);
    tmp2.resize(n_variable);
    for (int i=0;i<n_variable;i++) tmp2[i].resize(n_variable+n_sample_variable+1);
    int idx = 0, pre = 0;
    for (char * p = buf; p != buf_end; p++, idx++) {
        if (*p == ed) {buf_end = p+1; idx++; break;}
        if (*p == ';') {
            if (pre < idx) {
                _parser_upd(buf, pre, idx-1, tmp);

                for (int i=0;i<n_variable;i++) {
                    for (int j=0;j<n_variable+n_sample_variable+1;j++) {
                        tmp2[i][j] = (j<n_variable?0:tmp[i][j]);
                        for (int k=0;k<n_variable;k++) {
                            tmp2[i][j] += tmp[i][k] * upd[k][j];
                        }
                    }
                }
                for (int i=0;i<n_variable;i++)
                    for (int j=0;j<n_variable+n_sample_variable+1;j++) upd[i][j]=tmp2[i][j];
                pre = idx+1;
            }
        }
    }
    if (pre < idx) {
//        printf("pre = %d, idx = %d\n",pre,idx);
        _parser_upd(buf, pre, idx-1, tmp);

        for (int i=0;i<n_variable;i++) {
            for (int j=0;j<n_variable+n_sample_variable+1;j++) {
                tmp2[i][j] = (j<n_variable?0:tmp[i][j]);
                for (int k=0;k<n_variable;k++) {
                    tmp2[i][j] += tmp[i][k] * upd[k][j];
                }
            }
        }
        for (int i=0;i<n_variable;i++)
            for (int j=0;j<n_variable+n_sample_variable+1;j++) upd[i][j]=tmp2[i][j];
        pre = idx+1;
    }
    return buf;
}
void parser(const char * input_file) {
    FILE * fp = fopen(input_file, "r");

    // variables
    fscanf(fp, "%d", &n_variable);
    for (int i=0;i<n_variable;i++) {
        static char s[MAX_VAR_NAME_SIZE];
        fscanf(fp, "%s", s);
        string str(s, s+strlen(s));
        var_name_to_id[str] = i;
        var_id_to_name.push_back(str);
//        cout << "var[" << i << "].name = " << str << endl;

        double num;
        fscanf(fp, "%lf", &num);
        var_name_to_init_value[str] = num;
        var_id_to_init_value.push_back(num);
    }

    // sample variables

    fscanf(fp, "%d", &n_sample_variable);
    for (int i=0;i<n_sample_variable;i++) {
        static char s[MAX_VAR_NAME_SIZE];
        fscanf(fp, "%s", s);
        string str(s, s+strlen(s));
        sample_var_name_to_id[str] = i;
        sample_var_id_to_name.push_back(str);

        double a, b;
        fscanf(fp, "%lf%lf", &a, &b);
        assert(a < b);
        sample_var_id_to_value.push_back(make_pair(a, b));
        sample_var_id_to_E.push_back((a+b)/2.0);
    }


    static char buffer[MAX_BUF];
    int cur_line = 0;
    while (fgets(buffer, MAX_BUF, fp)) {
        cur_line++;
        int _i=0; for (int i=0;buffer[i];i++) {
            if (buffer[i]==' '|| buffer[i]=='\t' || buffer[i]=='\r' || buffer[i]=='\n') continue;
            buffer[_i++] = buffer[i];
        }
        buffer[_i] = 0;

        if (_i < 2 || (buffer[0]=='/' && buffer[1]=='/')) continue;

//        cout << "Line " << cur_line << " : [" << buffer << "]" << endl;

        int cnt = 0;
        int num1 = -10, num2 = -10, op1 = -1, op2 = -1, ed_id = -1;
        double prob = -10;

        cond * phi = 0;

        vector <vector<double> > upd;
        upd.resize(n_variable);
        for (int i=0;i<n_variable;i++) upd[i].resize(n_variable+n_sample_variable+1);
        for (int i=0;i<n_variable;i++) {
            for (int j=0;j<n_variable+n_sample_variable+1;j++) upd[i][j] = (i == j);
        }

        char * p = buffer, * pe = buffer + _i;
        p = parser_loc(p, pe, "*#", num1, op1, ed_id);
        if (ed_id == 1) {
            p = parser_phi(p, pe, '*', phi);
//            cout << "phi = " << *phi << endl;
            cir_poly[num1] = phi;
            continue;
        }
        p = parser_loc(p, pe, "*#", num2, op2, ed_id);
        if (pe-p>4 && p[0]=='p' && p[1]=='r' && p[2]=='o' && p[3]=='b' && p[4]=='(') {
            p = parser_prob(p, pe, '*', prob);
            p = parser_upd(p, pe, '*', upd);
//            cout << "upd = " << endl;
//            print_upd(upd);
        } else {
            p = parser_phi(p, pe, '*', phi);
//            cout << "phi = " << *phi << endl;
        }


        if (num1 < 0 || num2 < -2) {
            cout << "Something wrong! (Line " << cur_line << ")" << endl;
            assert(0);
        }

//        cout << "num1 = " << num1 << ", num2 = " << num2 << ", prob = " << prob << endl;
        // prob >= 0 -- sq_location -> cir_location
        // prob < 0 -- cir_location -> sq_location
        if (prob >= 0) {
            assert(op1 == 1 && op2 == 0);
            p_trans[num1].push_back(make_tuple(prob, upd, num2));
        } else {
            assert(op1 == 0 && op2 == 1);
            phi_trans[num1].push_back(make_pair(phi, num2));
        }

    }

//    cout << "n_cir_location = " << n_cir_location << endl;
//    cout << "n_sq_location = " << n_sq_location << endl;
}

// only for debug
void _check_parser() {
    for (int i=0;i<n_cir_location;i++) {
        cout << "cir " << i << ": I = [" << *cir_poly[i] << "]\n";
        for (int j=0;j<phi_trans[i].size();j++) {
            cout << "cond = [" << *phi_trans[i][j].first << "], ";
            cout << "point sq = [" << phi_trans[i][j].second << "]\n";
        }
    }

    for (int i=0;i<n_sq_location;i++) {
        cout << "sq " << i << ":\n";
        for (int j=0;j<p_trans[i].size();j++) {
            cout << "p = [" << get<0>(p_trans[i][j]) << "], ";
            cout << "upd = [";
            vector <vector<double> > upd = get<1>(p_trans[i][j]);
            for (int i=0;i<n_variable;i++) {
                cout << "[";
                for (int j=0;j<n_variable+n_sample_variable+1;j++) {
                    cout << upd[i][j] << ",]"[j==n_variable+n_sample_variable];
                }
                if (i<n_variable-1) cout << ",";
            }
            cout << "], point cir = [" << get<2>(p_trans[i][j]) << "]\n";
        }
    }
}

/*
argv[1] : input_file
*/
int main(int argc, char * argv[]) {
    clock_t start,finish;
    double totaltime;
    start=clock();

    if (argc == 2) {
        parser(argv[1]);
        string out_file_name(argv[1], argv[1]+strlen(argv[1]));
        int p = out_file_name.find_last_of(".");
        if (p != string::npos) out_file_name.erase(p);
        out_file_name += ".out";
        freopen(out_file_name.c_str(), "w", stdout);
    } else {
        cout << "Testing for example.in" << endl;
        cout << "Use ./AA_new_2 [input file path] for arbitrary input file\n\n" << endl;
        parser("./example.in");
        freopen("example.out", "w", stdout);
    }

//    _check_parser();

    // calculate invariant
    get_invariant();

    //cout << "step 2 :" << endl;
    //get_ineq();

    //cout << "\nstep 3 : " << endl;
    get_decomposition();

    cout << endl;

    finish=clock();
    totaltime=(double)(finish-start)/CLOCKS_PER_SEC;
    cout << "end\n";
    cout<<"% running time is  "<<totaltime<<"  second!"<<endl;

    return 0;
}



