file = dir('*.out')
len = length(file)
for i = 1 : len
   oldname = file(i).name;
   newname = strrep(oldname,'out','m');
   eval(['!rename' 32 oldname 32 newname]);
end