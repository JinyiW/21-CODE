st=cputime;
cvx_begin
	variable a_init_x
	variable b_init
	variable a_la_x
	variable b_la
	variable a_b1_x
	variable b_b1
	variable y_0
	variable y_1
	variable y_2
	variable y_3
	variable y_4
	variable y_5
	variable y_6
	variable y_7
	variable y_8
	variable y_9
	variable y_10
	variable y_11
	variable y_12
	variable y_13
	variable y_14
	variable y_15
	variable y_16
	maximize(100*a_init_x + b_init)
	subject to
		y_0 >= 0
		y_1 >= 0
		y_2 >= 0
		y_3 >= 0
		y_4 >= 0
		y_5 >= 0
		y_6 >= 0
		y_7 >= 0
		y_8 >= 0
		y_9 >= 0
		y_10 >= 0
		y_11 >= 0
		y_12 >= 0
		y_13 >= 0
		y_14 >= 0
		y_15 >= 0
		y_16 >= 0
		(-1.0000000000*y_0) + (1.0000000000*y_1) == a_init_x
		(-1.0000000000*y_2) + (1.0000000000*y_3) == a_la_x
		(-1.0000000000*y_4) + (1.0000000000*y_5) == a_b1_x
		(-1.0000000000*y_6) + (-1.0000000000*y_7) + (1.0000000000*y_8) == a_init_x - (1.0000000000*((1.0000000000*a_la_x)))
		(-0.0000000000*y_6) + (2.0000000000*y_7) + (1001.0000000000*y_8) <= 1.0000000000*((0.0000000000*a_la_x)+b_la) - b_init
		(1.0000000000*y_9) + (-1.0000000000*y_10) + (1.0000000000*y_11) == a_la_x - (1.0000000000*((1.0000000000*a_b1_x)))
		(1000.0000000000*y_9) + (-0.0000000000*y_10) + (1001.0000000000*y_11) <= 1.0000000000*((0.0000000000*a_b1_x)+b_b1) - b_la
		(-1.0000000000*y_12) + (-1.0000000000*y_13) + (1.0000000000*y_14) == a_la_x - (0)
		(-1001.0000000000*y_12) + (-0.0000000000*y_13) + (1001.0000000000*y_14) <= 0 - b_la
		(-1.0000000000*y_15) + (1.0000000000*y_16) == a_b1_x - (0.5000000000*((1.0000000000*a_init_x)) + 0.5000000000*((1.0000000000*a_init_x)))
		(0.0000000000*y_15) + (1000.0000000000*y_16) <= 0.5000000000*((-2.0000000000*a_init_x)+b_init) + 0.5000000000*((1.0000000000*a_init_x)+b_init) - b_b1
cvx_end
et=cputime-st


 %running time is  0.003  second!
