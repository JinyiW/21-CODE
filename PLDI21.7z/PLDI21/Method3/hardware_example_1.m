st=cputime;
cvx_begin
	variable a_init_x
	variable b_init
	variable y_0
	variable y_1
	variable y_2
	variable y_3
	variable y_4
	variable y_5
	variable y_6
	variable y_7
	maximize(20*a_init_x + b_init)
	subject to
		y_0 >= 0
		y_1 >= 0
		y_2 >= 0
		y_3 >= 0
		y_4 >= 0
		y_5 >= 0
		y_6 >= 0
		y_7 >= 0
		(-1.0000000000*y_0) + (1.0000000000*y_1) == a_init_x
		(1.0000000000*y_2) + (-1.0000000000*y_3) + (1.0000000000*y_4) == a_init_x - (0.7500000000*((1.0000000000*a_init_x)) + 0.2500000000*((1.0000000000*a_init_x)))
		(99.0000000000*y_2) + (0.0000000000*y_3) + (100.0000000000*y_4) <= 0.7500000000*((1.0000000000*a_init_x)+b_init) + 0.2500000000*((-1.0000000000*a_init_x)+b_init) - b_init + log(0.9999999000)
		(-1.0000000000*y_5) + (-1.0000000000*y_6) + (1.0000000000*y_7) == a_init_x - (0)
		(-100.0000000000*y_5) + (0.0000000000*y_6) + (100.0000000000*y_7) <= 0 - b_init
cvx_end
et=cputime-st


 %running time is  0.002  second!
